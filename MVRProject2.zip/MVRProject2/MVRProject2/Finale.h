﻿#pragma once
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
#include <msclr/marshal_cppstd.h> 
//#include <System::Windows::Forms> 
#include "opencv2/videoio.hpp"
#include <iostream>



namespace MVRProject2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;
	using namespace System::Threading::Tasks;
	using namespace System::Runtime::InteropServices;
	using namespace cv;

	/// <summary>
	/// Summary for Finale
	/// </summary>
	/// 
	public ref class Finale : public System::Windows::Forms::Form
	{
	public:
		Form^ obj;
		Finale(void)
			: closedEyeFrames(0)
		{
			InitializeComponent();
			faceCascade = new cv::CascadeClassifier();
			eyeCascade = new cv::CascadeClassifier();
		}
		Finale(Form^ obj1)
			: closedEyeFrames(0)
		{
			obj = obj1;
			InitializeComponent();
			faceCascade = new cv::CascadeClassifier();
			eyeCascade = new cv::CascadeClassifier();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Finale()
		{
			// delete the native OpenCV objects
			if (faceCascade) { delete faceCascade;  faceCascade = nullptr; }
			if (eyeCascade) { delete eyeCascade;   eyeCascade = nullptr; }

			// then delete the WinForms components
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ label2;





	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Finale::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->ForeColor = System::Drawing::Color::Transparent;
			this->button1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.Image")));
			this->button1->Location = System::Drawing::Point(117, 5);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(81, 76);
			this->button1->TabIndex = 0;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Finale::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(130, 84);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(55, 20);
			this->label1->TabIndex = 1;
			this->label1->Text = L"EXIT";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox1->Location = System::Drawing::Point(12, 114);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(921, 455);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 2;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Finale::pictureBox1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Aquire", 19.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(226, 20);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(573, 33);
			this->label2->TabIndex = 3;
			this->label2->Text = L"FACE DROWSINESS RECOGNITION";
			this->label2->Click += gcnew System::EventHandler(this, &Finale::label2_Click);
			// 
			// Finale
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->ClientSize = System::Drawing::Size(945, 589);
			this->ControlBox = false;
			this->Controls->Add(this->label2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->Name = L"Finale";
			this->ShowIcon = false;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"RECOGNITION";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Finale::Finale_FormClosing);
			this->Load += gcnew System::EventHandler(this, &Finale::Finale_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

#pragma region LocalVariables
	private: Thread^ StreamThreadHandle;
#pragma endregion

#pragma region delegates
	private: delegate void UPDATE_FRAME(Bitmap^ b);

	private: void UpdateFrame(Bitmap^ b)
	{
		pictureBox1->Image = b;
	}
#pragma endregion

#pragma region DrowsinessDetectionMembers
	private:
		// native pointers OK inside a managed ref class
		cv::CascadeClassifier* faceCascade;
		cv::CascadeClassifier* eyeCascade;
		int closedEyeFrames;
		literal int CLOSED_FRAMES_THRESHOLD = 5;  // compile-time constant
#pragma endregion


#pragma region ThreadsFunctions
private:
	void StreamThread()
	{
		// 1) open camera
		cv::VideoCapture capture(0);
		if (!capture.isOpened()) {
			MessageBox::Show("Error! No Camera is found.");
			return;
		}

		// 2) prepare mats & vectors
		cv::Mat frame, gray, mirrored;
		std::vector<cv::Rect> faces, eyes;

		// Hysteresis counters
		int openEyeFrames = 0;   // count of consecutive frames where eyes ARE detected
		const int OPEN_THRESHOLD = 3; // require 3 straight “open” frames to clear alert

		// 3) main loop
		while (capture.read(frame)) {
			if (frame.empty()) break;

			// -- mirror --
			cv::flip(frame, mirrored, 1);

			// -- grayscale + equalize --
			cv::cvtColor(mirrored, gray, cv::COLOR_BGR2GRAY);
			cv::equalizeHist(gray, gray);

			// clear last detections
			faces.clear();
			eyes.clear();

			// -- face detection (only the biggest face) --
			faceCascade->detectMultiScale(
				gray, faces,
				1.2,                   // scaleFactor
				3,                     // minNeighbors (use integer)
				cv::CASCADE_SCALE_IMAGE |
				cv::CASCADE_FIND_BIGGEST_OBJECT,
				cv::Size(100, 100)
			);

			if (!faces.empty()) {
				cv::Rect faceROI = faces[0];

				// -- eye detection within the face region --
				cv::Mat faceGray = gray(faceROI);
				eyeCascade->detectMultiScale(
					faceGray, eyes,
					1.2,                 // scaleFactor
					3,                   // minNeighbors
					cv::CASCADE_SCALE_IMAGE,
					cv::Size(15, 15)
				);

				// ** hysteresis: only reset closedEyeFrames after OPEN_THRESHOLD good frames **
				if (eyes.empty()) {
					++closedEyeFrames;
					openEyeFrames = 0;
				}
				else {
					++openEyeFrames;
					if (openEyeFrames >= OPEN_THRESHOLD) {
						closedEyeFrames = 0;
					}
				}

				// ** drowsiness alert **
				if (closedEyeFrames > CLOSED_FRAMES_THRESHOLD) {
					cv::putText(
						mirrored,
						"DROWSINESS ALERT!",
						cv::Point(faceROI.x, faceROI.y - 0),  // position above face
						cv::FONT_HERSHEY_DUPLEX,
						1.1,
						cv::Scalar(0, 0, 255),
						2
					);
				}
			}
			else {
				// no face → reset both counters
				closedEyeFrames = 0;
				openEyeFrames = 0;
			}

			// -- convert to Bitmap^ and invoke UI update --
			Bitmap^ b = gcnew Bitmap(
				mirrored.cols,
				mirrored.rows,
				mirrored.step,
				Imaging::PixelFormat::Format24bppRgb,
				System::IntPtr(mirrored.data)
			);

			if (pictureBox1->InvokeRequired) {
				UPDATE_FRAME^ cb = gcnew UPDATE_FRAME(this, &Finale::UpdateFrame);
				Control::Invoke(cb, b);
			}
			else {
				UpdateFrame(b);
				delete b;
			}
		}

		capture.release();
	}
#pragma endregion



	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		this->Close();
		obj->Show();
	}

	private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void Finale_Load(System::Object^ sender, System::EventArgs^ e) {
		// Hard‐coded absolute paths to your cascades:
		const std::string facePath = "C:\\opencv\\build\\etc\\haarcascades\\haarcascade_frontalface_default.xml";
		const std::string eyePath = "C:\\opencv\\build\\etc\\haarcascades\\haarcascade_eye_tree_eyeglasses.xml";

		// Try loading them
		if (!faceCascade->load(facePath)) {
			System::Windows::Forms::MessageBox::Show(
				"Could not load face cascade:\n" + gcnew System::String(facePath.c_str()),
				"Load Error",
				System::Windows::Forms::MessageBoxButtons::OK,
				System::Windows::Forms::MessageBoxIcon::Error
			);
			this->Close();
			return;
		}
		if (!eyeCascade->load(eyePath)) {
			System::Windows::Forms::MessageBox::Show(
				"Could not load eye cascade:\n" + gcnew System::String(eyePath.c_str()),
				"Load Error",
				System::Windows::Forms::MessageBoxButtons::OK,
				System::Windows::Forms::MessageBoxIcon::Error
			);
			this->Close();
			return;
		}

		// If we reach here, both cascades are loaded—start the stream thread:
		StreamThreadHandle = gcnew System::Threading::Thread(
			gcnew System::Threading::ThreadStart(this, &Finale::StreamThread)
		);
		StreamThreadHandle->Start();
	}


	private: System::Void Finale_FormClosing(System::Object^ sender, System::Windows::Forms::FormClosingEventArgs^ e) {
		//We need to kill the thread if Form is closed
		if (StreamThreadHandle != nullptr)
		{
			if (true == StreamThreadHandle->IsAlive)
			{
				StreamThreadHandle->Abort();
			}
		}
	}
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label6_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {

	}

	};
}