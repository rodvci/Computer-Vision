﻿#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <msclr/marshal_cppstd.h>
#include <vector>
#include <cmath>
#include <fstream>
#include <msclr\marshal_cppstd.h>
#include <algorithm>
#include "Finale.h"






int lastRedValue = 0;
int lastGreenValue = 0;
int lastBlueValue = 0;
// Global variable to track rotation angle
int rotationAngle = 0;
#pragma once

namespace MVRProject2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Imaging;
	using namespace cv;

	/*int lastRedValue = 0;
	int lastGreenValue = 0;
	int lastBlueValue = 0;
	// Global variable to track rotation angle
	int rotationAngle = 0;*/
	

	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			originalBitmap = nullptr;
		}
	protected:
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
			if (originalBitmap)
			{
				delete originalBitmap;
			}
		}

	private:
		Bitmap^ modifiedBitmap = nullptr;

	private:
		System::Drawing::Bitmap^ originalBitmap;
		System::Drawing::Point seedPoint;
		


	



	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;



	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TrackBar^ trackBar1;
	private: System::Windows::Forms::TrackBar^ trackBar_Blue;

	private: System::Windows::Forms::TrackBar^ trackBar_Green;

	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TrackBar^ trackBar_Red;





	private: System::Windows::Forms::Panel^ panel2;


	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Panel^ panel6;
	private: System::Windows::Forms::Panel^ panel7;
	private: System::Windows::Forms::Panel^ panel8;
	private: System::Windows::Forms::Panel^ panel9;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TrackBar^ Opacity;




	private: System::Windows::Forms::TrackBar^ trackBar6;
	private: System::Windows::Forms::TrackBar^ trackBar7;
	private: System::Windows::Forms::TrackBar^ trackBar8;
	private: System::Windows::Forms::TrackBar^ trackBar9;






















private: System::Windows::Forms::Panel^ panel3;
private: System::Windows::Forms::Panel^ panel4;


private: System::Windows::Forms::Label^ label7;

private: System::Windows::Forms::Button^ RstrgbTrckBars;
private: System::Windows::Forms::Button^ RstEnhanceAdjust;
private: System::Windows::Forms::Button^ ThresRst;
private: System::Windows::Forms::Button^ GrySclBtn;
private: System::Windows::Forms::Button^ BWBtn;
private: System::Windows::Forms::Button^ SlctBtn;

private: System::Windows::Forms::Button^ QtBtn;
private: System::Windows::Forms::Panel^ panel1;

private: System::Windows::Forms::Button^ button10;
private: System::Windows::Forms::Label^ label3;
private: System::Windows::Forms::Button^ button9;
private: System::Windows::Forms::Button^ button1;
private: System::Windows::Forms::Button^ button2;
private: System::Windows::Forms::Button^ button8;
private: System::Windows::Forms::Button^ button3;
private: System::Windows::Forms::Button^ button7;
private: System::Windows::Forms::Button^ button4;
private: System::Windows::Forms::Button^ button5;
private: System::Windows::Forms::Button^ button6;
private: System::Windows::Forms::Button^ SvImg;
private: System::Windows::Forms::Button^ ClrImg;
private: System::Windows::Forms::Label^ label8;

private: System::Windows::Forms::Button^ AdaptiveBinary;



private: System::Windows::Forms::Panel^ OptnPnl1;

private: System::Windows::Forms::Label^ label9;
private: System::Windows::Forms::Button^ CheckColorObjectBtn;
private: System::Windows::Forms::Button^ CheckObjectBtn;
private: System::Windows::Forms::Panel^ panel11;
private: System::Windows::Forms::Label^ label11;
private: System::Windows::Forms::Label^ label10;
private: System::Windows::Forms::Label^ label12;
private: System::Windows::Forms::Label^ label13;
private: System::Windows::Forms::Label^ label14;
private: System::Windows::Forms::Label^ label15;
private: System::Windows::Forms::Label^ label16;
private: System::Windows::Forms::Label^ label17;
private: System::Windows::Forms::Panel^ panel12;
private: System::Windows::Forms::Button^ AreaImgBtn;
private: System::Windows::Forms::Panel^ panel13;
private: System::Windows::Forms::Label^ label20;
private: System::Windows::Forms::Button^ AreaObjctBtn;


private: System::Windows::Forms::Label^ label19;
private: System::Windows::Forms::Label^ label18;
private: System::Windows::Forms::Label^ label21;
private: System::Windows::Forms::Label^ label24;
private: System::Windows::Forms::Label^ label22;
private: System::Windows::Forms::Button^ CntrObjctBtn;

private: System::Windows::Forms::Button^ CntrImgBtn;

private: System::Windows::Forms::Label^ label23;
private: System::Windows::Forms::Label^ label25;

private: System::Windows::Forms::Button^ button11;
private: System::Windows::Forms::Label^ label27;
private: System::Windows::Forms::Button^ button12;
private: System::Windows::Forms::Label^ label26;
private: System::Windows::Forms::Label^ label28;
private: System::Windows::Forms::Label^ label29;
private: System::Windows::Forms::Panel^ panel15;
private: System::Windows::Forms::Panel^ panel14;
private: System::Windows::Forms::Panel^ panel16;
private: System::Windows::Forms::Label^ label30;
private: System::Windows::Forms::Label^ label31;
private: System::Windows::Forms::Label^ label32;
private: System::Windows::Forms::Label^ label33;
private: System::Windows::Forms::Label^ label34;
private: System::Windows::Forms::Button^ button13;
private: System::Windows::Forms::Label^ label35;

private: System::Windows::Forms::Label^ label37;
private: System::Windows::Forms::Label^ label36;
private: System::Windows::Forms::Button^ button14;
private: System::Windows::Forms::Label^ label38;
private: System::Windows::Forms::Label^ label40;
private: System::Windows::Forms::Label^ label39;
private: System::Windows::Forms::Label^ label41;









private: System::Windows::Forms::Panel^ panel19;
private: System::Windows::Forms::Panel^ panel18;
private: System::Windows::Forms::TrackBar^ trackBar3;
private: System::Windows::Forms::Panel^ panel20;
private: System::Windows::Forms::TrackBar^ trackBar4;
private: System::Windows::Forms::Label^ label42;
private: System::Windows::Forms::Panel^ panel21;
private: System::Windows::Forms::TrackBar^ trackBar5;
private: System::Windows::Forms::Panel^ panel10;
private: System::Windows::Forms::Label^ label43;
private: System::Windows::Forms::Button^ button16;
private: System::Windows::Forms::Button^ button15;


private: System::Windows::Forms::Button^ button19;
private: System::Windows::Forms::Button^ button18;
private: System::Windows::Forms::Button^ button20;

private: System::Windows::Forms::Button^ button21;
private: System::Windows::Forms::Button^ button22;
private: System::Windows::Forms::Label^ label45;
private: System::Windows::Forms::Label^ label46;
private: System::Windows::Forms::Label^ label50;
private: System::Windows::Forms::Panel^ panel17;
private: System::Windows::Forms::TrackBar^ trackBar2;
private: System::Windows::Forms::Label^ label44;
private: System::Windows::Forms::Label^ label47;
private: System::Windows::Forms::Button^ button17;

private: System::Windows::Forms::PictureBox^ pictureBox4;
private: System::Windows::Forms::PictureBox^ pictureBox5;
private: System::Windows::Forms::PictureBox^ pictureBox3;
private: System::Windows::Forms::Button^ button23;
private: System::Windows::Forms::TextBox^ textBox2;
private: System::Windows::Forms::TextBox^ textBox1;
private: System::Windows::Forms::Label^ label49;
private: System::Windows::Forms::Label^ label48;
private: System::Windows::Forms::Label^ label54;
private: System::Windows::Forms::Label^ label51;
private: System::Windows::Forms::Label^ label52;
private: System::Windows::Forms::Label^ label53;
private: System::Windows::Forms::Button^ button24;
private: System::Windows::Forms::Label^ label57;
private: System::Windows::Forms::Button^ button26;
private: System::Windows::Forms::Label^ label56;
private: System::Windows::Forms::Button^ button25;
private: System::Windows::Forms::Label^ label55;
private: System::Windows::Forms::Label^ label58;
private: System::Windows::Forms::Button^ button27;
private: System::Windows::Forms::Label^ label59;
private: System::Windows::Forms::Button^ button28;
private: System::Windows::Forms::Panel^ panel22;











private: System::Windows::Forms::TextBox^ textBox8;
private: System::Windows::Forms::TextBox^ textBox7;
private: System::Windows::Forms::TextBox^ textBox6;
private: System::Windows::Forms::TextBox^ textBox5;
private: System::Windows::Forms::TextBox^ textBox4;
private: System::Windows::Forms::TextBox^ textBox3;
private: System::Windows::Forms::TextBox^ textBox9;
private: System::Windows::Forms::TextBox^ textBox10;
private: System::Windows::Forms::TextBox^ textBox11;
private: System::Windows::Forms::Button^ button29;
private: System::Windows::Forms::Button^ button30;
private: System::Windows::Forms::Label^ label60;
private: System::Windows::Forms::Label^ label61;
private: System::Windows::Forms::Button^ button31;




















































	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->trackBar1 = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar_Red = (gcnew System::Windows::Forms::TrackBar());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->trackBar_Green = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar_Blue = (gcnew System::Windows::Forms::TrackBar());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->panel8 = (gcnew System::Windows::Forms::Panel());
			this->panel9 = (gcnew System::Windows::Forms::Panel());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->Opacity = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar6 = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar7 = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar8 = (gcnew System::Windows::Forms::TrackBar());
			this->trackBar9 = (gcnew System::Windows::Forms::TrackBar());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->RstrgbTrckBars = (gcnew System::Windows::Forms::Button());
			this->RstEnhanceAdjust = (gcnew System::Windows::Forms::Button());
			this->ThresRst = (gcnew System::Windows::Forms::Button());
			this->GrySclBtn = (gcnew System::Windows::Forms::Button());
			this->BWBtn = (gcnew System::Windows::Forms::Button());
			this->SlctBtn = (gcnew System::Windows::Forms::Button());
			this->QtBtn = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->panel11 = (gcnew System::Windows::Forms::Panel());
			this->CheckObjectBtn = (gcnew System::Windows::Forms::Button());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->CheckColorObjectBtn = (gcnew System::Windows::Forms::Button());
			this->SvImg = (gcnew System::Windows::Forms::Button());
			this->ClrImg = (gcnew System::Windows::Forms::Button());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->AdaptiveBinary = (gcnew System::Windows::Forms::Button());
			this->OptnPnl1 = (gcnew System::Windows::Forms::Panel());
			this->panel10 = (gcnew System::Windows::Forms::Panel());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->button31 = (gcnew System::Windows::Forms::Button());
			this->panel22 = (gcnew System::Windows::Forms::Panel());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->button30 = (gcnew System::Windows::Forms::Button());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->button29 = (gcnew System::Windows::Forms::Button());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->label59 = (gcnew System::Windows::Forms::Label());
			this->button28 = (gcnew System::Windows::Forms::Button());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->button27 = (gcnew System::Windows::Forms::Button());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->button26 = (gcnew System::Windows::Forms::Button());
			this->button25 = (gcnew System::Windows::Forms::Button());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->panel16 = (gcnew System::Windows::Forms::Panel());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->panel15 = (gcnew System::Windows::Forms::Panel());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->trackBar2 = (gcnew System::Windows::Forms::TrackBar());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->panel14 = (gcnew System::Windows::Forms::Panel());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->panel13 = (gcnew System::Windows::Forms::Panel());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->AreaObjctBtn = (gcnew System::Windows::Forms::Button());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->CntrObjctBtn = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->CntrImgBtn = (gcnew System::Windows::Forms::Button());
			this->AreaImgBtn = (gcnew System::Windows::Forms::Button());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->panel12 = (gcnew System::Windows::Forms::Panel());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->panel19 = (gcnew System::Windows::Forms::Panel());
			this->panel18 = (gcnew System::Windows::Forms::Panel());
			this->trackBar3 = (gcnew System::Windows::Forms::TrackBar());
			this->panel20 = (gcnew System::Windows::Forms::Panel());
			this->trackBar4 = (gcnew System::Windows::Forms::TrackBar());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->panel21 = (gcnew System::Windows::Forms::Panel());
			this->trackBar5 = (gcnew System::Windows::Forms::TrackBar());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->panel17 = (gcnew System::Windows::Forms::Panel());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Red))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Green))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Blue))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Opacity))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar9))->BeginInit();
			this->panel1->SuspendLayout();
			this->panel11->SuspendLayout();
			this->OptnPnl1->SuspendLayout();
			this->panel10->SuspendLayout();
			this->panel22->SuspendLayout();
			this->panel16->SuspendLayout();
			this->panel15->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar2))->BeginInit();
			this->panel14->SuspendLayout();
			this->panel13->SuspendLayout();
			this->panel12->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar5))->BeginInit();
			this->panel17->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->pictureBox1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.BackgroundImage")));
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox1->Location = System::Drawing::Point(1042, 33);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(408, 394);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 1;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->WaitOnLoad = true;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &MyForm::pictureBox1_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->pictureBox2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.BackgroundImage")));
			this->pictureBox2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox2->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox2->Location = System::Drawing::Point(1470, 33);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(408, 394);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox2->TabIndex = 2;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &MyForm::pictureBox2_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label1->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Location = System::Drawing::Point(1104, 12);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(299, 18);
			this->label1->TabIndex = 3;
			this->label1->Text = L"U N A L T E R E D  P H O T O";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label2->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label2->Location = System::Drawing::Point(1500, 10);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(343, 18);
			this->label2->TabIndex = 4;
			this->label2->Text = L"T R A N S F O R M E D  P H O T O";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label4->Font = (gcnew System::Drawing::Font(L"Black Future", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label4->Location = System::Drawing::Point(674, 17);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(194, 18);
			this->label4->TabIndex = 10;
			this->label4->Text = L"P H O T O  T H R E S H O L D";
			this->label4->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// trackBar1
			// 
			this->trackBar1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar1->LargeChange = 1;
			this->trackBar1->Location = System::Drawing::Point(741, 39);
			this->trackBar1->Maximum = 100;
			this->trackBar1->Name = L"trackBar1";
			this->trackBar1->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar1->Size = System::Drawing::Size(261, 56);
			this->trackBar1->TabIndex = 26;
			this->trackBar1->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar1_Scroll);
			// 
			// trackBar_Red
			// 
			this->trackBar_Red->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar_Red->Location = System::Drawing::Point(743, 389);
			this->trackBar_Red->Maximum = 100;
			this->trackBar_Red->Minimum = -100;
			this->trackBar_Red->Name = L"trackBar_Red";
			this->trackBar_Red->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar_Red->Size = System::Drawing::Size(265, 56);
			this->trackBar_Red->TabIndex = 27;
			this->trackBar_Red->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar2_Scroll);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label5->Font = (gcnew System::Drawing::Font(L"Black Future", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label5->Location = System::Drawing::Point(676, 352);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(106, 21);
			this->label5->TabIndex = 27;
			this->label5->Text = L"PHOTO RGB";
			this->label5->Click += gcnew System::EventHandler(this, &MyForm::label5_Click);
			// 
			// trackBar_Green
			// 
			this->trackBar_Green->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar_Green->Location = System::Drawing::Point(743, 451);
			this->trackBar_Green->Maximum = 100;
			this->trackBar_Green->Minimum = -100;
			this->trackBar_Green->Name = L"trackBar_Green";
			this->trackBar_Green->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar_Green->Size = System::Drawing::Size(265, 56);
			this->trackBar_Green->TabIndex = 28;
			this->trackBar_Green->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar3_Scroll);
			// 
			// trackBar_Blue
			// 
			this->trackBar_Blue->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar_Blue->Location = System::Drawing::Point(743, 513);
			this->trackBar_Blue->Maximum = 100;
			this->trackBar_Blue->Minimum = -100;
			this->trackBar_Blue->Name = L"trackBar_Blue";
			this->trackBar_Blue->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar_Blue->Size = System::Drawing::Size(265, 56);
			this->trackBar_Blue->TabIndex = 29;
			this->trackBar_Blue->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar4_Scroll);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel2.BackgroundImage")));
			this->panel2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel2->Location = System::Drawing::Point(679, 377);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(60, 54);
			this->panel2->TabIndex = 33;
			// 
			// panel5
			// 
			this->panel5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel5->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel5.BackgroundImage")));
			this->panel5->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel5->Location = System::Drawing::Point(681, 616);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(60, 55);
			this->panel5->TabIndex = 35;
			// 
			// panel6
			// 
			this->panel6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel6->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel6.BackgroundImage")));
			this->panel6->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel6->Location = System::Drawing::Point(681, 677);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(60, 55);
			this->panel6->TabIndex = 36;
			// 
			// panel7
			// 
			this->panel7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel7->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel7.BackgroundImage")));
			this->panel7->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel7->Location = System::Drawing::Point(681, 738);
			this->panel7->Name = L"panel7";
			this->panel7->Size = System::Drawing::Size(60, 55);
			this->panel7->TabIndex = 37;
			// 
			// panel8
			// 
			this->panel8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel8->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel8.BackgroundImage")));
			this->panel8->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel8->Location = System::Drawing::Point(681, 799);
			this->panel8->Name = L"panel8";
			this->panel8->Size = System::Drawing::Size(60, 55);
			this->panel8->TabIndex = 38;
			// 
			// panel9
			// 
			this->panel9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel9->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel9.BackgroundImage")));
			this->panel9->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel9->Location = System::Drawing::Point(681, 860);
			this->panel9->Name = L"panel9";
			this->panel9->Size = System::Drawing::Size(60, 55);
			this->panel9->TabIndex = 39;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label6->Font = (gcnew System::Drawing::Font(L"Black Future", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label6->Location = System::Drawing::Point(678, 591);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(147, 21);
			this->label6->TabIndex = 40;
			this->label6->Text = L"ENHANCE PHOTO";
			// 
			// Opacity
			// 
			this->Opacity->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->Opacity->Location = System::Drawing::Point(747, 616);
			this->Opacity->Maximum = 100;
			this->Opacity->Name = L"Opacity";
			this->Opacity->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->Opacity->Size = System::Drawing::Size(255, 56);
			this->Opacity->TabIndex = 41;
			this->Opacity->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar5_Scroll);
			// 
			// trackBar6
			// 
			this->trackBar6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar6->Location = System::Drawing::Point(747, 677);
			this->trackBar6->Maximum = 100;
			this->trackBar6->Name = L"trackBar6";
			this->trackBar6->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar6->Size = System::Drawing::Size(255, 56);
			this->trackBar6->TabIndex = 42;
			this->trackBar6->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar6_Scroll);
			// 
			// trackBar7
			// 
			this->trackBar7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar7->Location = System::Drawing::Point(747, 737);
			this->trackBar7->Maximum = 100;
			this->trackBar7->Name = L"trackBar7";
			this->trackBar7->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar7->Size = System::Drawing::Size(255, 56);
			this->trackBar7->TabIndex = 43;
			this->trackBar7->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar7_Scroll);
			// 
			// trackBar8
			// 
			this->trackBar8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar8->Location = System::Drawing::Point(747, 799);
			this->trackBar8->Maximum = 100;
			this->trackBar8->Name = L"trackBar8";
			this->trackBar8->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar8->Size = System::Drawing::Size(255, 56);
			this->trackBar8->TabIndex = 44;
			this->trackBar8->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar8_Scroll);
			// 
			// trackBar9
			// 
			this->trackBar9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar9->Location = System::Drawing::Point(747, 859);
			this->trackBar9->Maximum = 100;
			this->trackBar9->Name = L"trackBar9";
			this->trackBar9->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar9->Size = System::Drawing::Size(255, 56);
			this->trackBar9->TabIndex = 45;
			this->trackBar9->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar9_Scroll);
			// 
			// panel3
			// 
			this->panel3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel3.BackgroundImage")));
			this->panel3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel3->Location = System::Drawing::Point(679, 437);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(60, 54);
			this->panel3->TabIndex = 34;
			// 
			// panel4
			// 
			this->panel4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel4->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel4.BackgroundImage")));
			this->panel4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel4->Location = System::Drawing::Point(679, 497);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(60, 54);
			this->panel4->TabIndex = 34;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label7->Font = (gcnew System::Drawing::Font(L"Aquire Light", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label7->Location = System::Drawing::Point(1884, 12);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(30, 200);
			this->label7->TabIndex = 46;
			this->label7->Text = L"R\r\nO\r\nD \r\n\r\nC\r\nA\r\nP\r\nI\r\nL\r\nI";
			this->label7->Click += gcnew System::EventHandler(this, &MyForm::label7_Click_1);
			// 
			// RstrgbTrckBars
			// 
			this->RstrgbTrckBars->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RstrgbTrckBars.BackgroundImage")));
			this->RstrgbTrckBars->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->RstrgbTrckBars->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RstrgbTrckBars->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RstrgbTrckBars->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->RstrgbTrckBars->Location = System::Drawing::Point(972, 352);
			this->RstrgbTrckBars->Name = L"RstrgbTrckBars";
			this->RstrgbTrckBars->Size = System::Drawing::Size(32, 31);
			this->RstrgbTrckBars->TabIndex = 47;
			this->RstrgbTrckBars->UseVisualStyleBackColor = false;
			this->RstrgbTrckBars->Click += gcnew System::EventHandler(this, &MyForm::RstrgbTrckBars_Click);
			// 
			// RstEnhanceAdjust
			// 
			this->RstEnhanceAdjust->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"RstEnhanceAdjust.BackgroundImage")));
			this->RstEnhanceAdjust->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->RstEnhanceAdjust->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->RstEnhanceAdjust->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->RstEnhanceAdjust->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->RstEnhanceAdjust->Location = System::Drawing::Point(970, 585);
			this->RstEnhanceAdjust->Name = L"RstEnhanceAdjust";
			this->RstEnhanceAdjust->Size = System::Drawing::Size(32, 31);
			this->RstEnhanceAdjust->TabIndex = 48;
			this->RstEnhanceAdjust->UseVisualStyleBackColor = false;
			this->RstEnhanceAdjust->Click += gcnew System::EventHandler(this, &MyForm::RstEnhanceAdjust_Click);
			// 
			// ThresRst
			// 
			this->ThresRst->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"ThresRst.BackgroundImage")));
			this->ThresRst->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ThresRst->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->ThresRst->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ThresRst->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->ThresRst->Location = System::Drawing::Point(970, 10);
			this->ThresRst->Name = L"ThresRst";
			this->ThresRst->Size = System::Drawing::Size(32, 31);
			this->ThresRst->TabIndex = 49;
			this->ThresRst->UseVisualStyleBackColor = false;
			this->ThresRst->Click += gcnew System::EventHandler(this, &MyForm::button11_Click_1);
			// 
			// GrySclBtn
			// 
			this->GrySclBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->GrySclBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"GrySclBtn.BackgroundImage")));
			this->GrySclBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->GrySclBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->GrySclBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->GrySclBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->GrySclBtn->Location = System::Drawing::Point(16, 4);
			this->GrySclBtn->Name = L"GrySclBtn";
			this->GrySclBtn->Size = System::Drawing::Size(68, 63);
			this->GrySclBtn->TabIndex = 3;
			this->GrySclBtn->UseVisualStyleBackColor = false;
			this->GrySclBtn->Click += gcnew System::EventHandler(this, &MyForm::GrySclBtn_Click);
			// 
			// BWBtn
			// 
			this->BWBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->BWBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"BWBtn.BackgroundImage")));
			this->BWBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->BWBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->BWBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->BWBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->BWBtn->Location = System::Drawing::Point(16, 105);
			this->BWBtn->Name = L"BWBtn";
			this->BWBtn->Size = System::Drawing::Size(68, 63);
			this->BWBtn->TabIndex = 4;
			this->BWBtn->UseVisualStyleBackColor = false;
			this->BWBtn->Click += gcnew System::EventHandler(this, &MyForm::BWBtn_Click);
			// 
			// SlctBtn
			// 
			this->SlctBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(134)), static_cast<System::Int32>(static_cast<System::Byte>(185)),
				static_cast<System::Int32>(static_cast<System::Byte>(176)));
			this->SlctBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"SlctBtn.BackgroundImage")));
			this->SlctBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->SlctBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SlctBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->SlctBtn->Location = System::Drawing::Point(8, 32);
			this->SlctBtn->Name = L"SlctBtn";
			this->SlctBtn->Size = System::Drawing::Size(70, 64);
			this->SlctBtn->TabIndex = 0;
			this->SlctBtn->UseVisualStyleBackColor = false;
			this->SlctBtn->Click += gcnew System::EventHandler(this, &MyForm::SlctBtn_Click);
			// 
			// QtBtn
			// 
			this->QtBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(134)), static_cast<System::Int32>(static_cast<System::Byte>(185)),
				static_cast<System::Int32>(static_cast<System::Byte>(176)));
			this->QtBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"QtBtn.BackgroundImage")));
			this->QtBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->QtBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->QtBtn->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->QtBtn->Location = System::Drawing::Point(236, 35);
			this->QtBtn->Name = L"QtBtn";
			this->QtBtn->Size = System::Drawing::Size(70, 63);
			this->QtBtn->TabIndex = 6;
			this->QtBtn->UseVisualStyleBackColor = false;
			this->QtBtn->Click += gcnew System::EventHandler(this, &MyForm::QtBtn_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel1->Controls->Add(this->button10);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->button9);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->button8);
			this->panel1->Controls->Add(this->button3);
			this->panel1->Controls->Add(this->button7);
			this->panel1->Controls->Add(this->button4);
			this->panel1->Controls->Add(this->button5);
			this->panel1->Controls->Add(this->button6);
			this->panel1->Location = System::Drawing::Point(11, 10);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(250, 233);
			this->panel1->TabIndex = 8;
			this->panel1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel1_Paint);
			// 
			// button10
			// 
			this->button10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button10->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button10->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button10->Location = System::Drawing::Point(121, 191);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(111, 36);
			this->button10->TabIndex = 15;
			this->button10->Text = L"FADE";
			this->button10->UseVisualStyleBackColor = false;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button10_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label3->Location = System::Drawing::Point(3, 6);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(125, 15);
			this->label3->TabIndex = 5;
			this->label3->Text = L"PHOTO FILTERS:";
			// 
			// button9
			// 
			this->button9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button9->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button9->Location = System::Drawing::Point(6, 191);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(111, 36);
			this->button9->TabIndex = 14;
			this->button9->Text = L"VIVID";
			this->button9->UseVisualStyleBackColor = false;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button1->Location = System::Drawing::Point(5, 24);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(111, 36);
			this->button1->TabIndex = 6;
			this->button1->Text = L"GOLDEN";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button2->Location = System::Drawing::Point(121, 24);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(111, 36);
			this->button2->TabIndex = 7;
			this->button2->Text = L"NEGATIVE";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button8->Location = System::Drawing::Point(121, 149);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(111, 36);
			this->button8->TabIndex = 13;
			this->button8->Text = L"CYBERPUNK";
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button3->Location = System::Drawing::Point(5, 66);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(111, 36);
			this->button3->TabIndex = 8;
			this->button3->Text = L"WARM";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button7->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button7->Location = System::Drawing::Point(5, 149);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(111, 36);
			this->button7->TabIndex = 12;
			this->button7->Text = L"LILY";
			this->button7->UseVisualStyleBackColor = false;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button4->Location = System::Drawing::Point(122, 66);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(111, 36);
			this->button4->TabIndex = 9;
			this->button4->Text = L"SEPIA";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button5->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button5->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button5->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button5->Location = System::Drawing::Point(6, 108);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(111, 36);
			this->button5->TabIndex = 10;
			this->button5->Text = L"COOL";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button6->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button6->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button6->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button6->Location = System::Drawing::Point(123, 107);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(111, 36);
			this->button6->TabIndex = 11;
			this->button6->Text = L"NATURE";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// panel11
			// 
			this->panel11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel11->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel11->Controls->Add(this->CheckObjectBtn);
			this->panel11->Controls->Add(this->label10);
			this->panel11->Controls->Add(this->label11);
			this->panel11->Controls->Add(this->label9);
			this->panel11->Controls->Add(this->CheckColorObjectBtn);
			this->panel11->Location = System::Drawing::Point(11, 249);
			this->panel11->Name = L"panel11";
			this->panel11->Size = System::Drawing::Size(250, 132);
			this->panel11->TabIndex = 37;
			// 
			// CheckObjectBtn
			// 
			this->CheckObjectBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CheckObjectBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"CheckObjectBtn.BackgroundImage")));
			this->CheckObjectBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->CheckObjectBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CheckObjectBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CheckObjectBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CheckObjectBtn->Location = System::Drawing::Point(142, 27);
			this->CheckObjectBtn->Name = L"CheckObjectBtn";
			this->CheckObjectBtn->Size = System::Drawing::Size(68, 63);
			this->CheckObjectBtn->TabIndex = 49;
			this->CheckObjectBtn->UseVisualStyleBackColor = false;
			this->CheckObjectBtn->Click += gcnew System::EventHandler(this, &MyForm::CheckObjectBtn_Click);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label10->Location = System::Drawing::Point(141, 93);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(69, 18);
			this->label10->TabIndex = 49;
			this->label10->Text = L"SHAPE";
			this->label10->Click += gcnew System::EventHandler(this, &MyForm::label10_Click);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label11->Location = System::Drawing::Point(26, 93);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(71, 18);
			this->label11->TabIndex = 50;
			this->label11->Text = L"COLOR";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label9->Location = System::Drawing::Point(3, 9);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(81, 18);
			this->label9->TabIndex = 37;
			this->label9->Text = L"DETECT";
			this->label9->Click += gcnew System::EventHandler(this, &MyForm::label9_Click);
			// 
			// CheckColorObjectBtn
			// 
			this->CheckColorObjectBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)),
				static_cast<System::Int32>(static_cast<System::Byte>(38)), static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CheckColorObjectBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"CheckColorObjectBtn.BackgroundImage")));
			this->CheckColorObjectBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->CheckColorObjectBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CheckColorObjectBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CheckColorObjectBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)),
				static_cast<System::Int32>(static_cast<System::Byte>(38)), static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CheckColorObjectBtn->Location = System::Drawing::Point(29, 27);
			this->CheckColorObjectBtn->Name = L"CheckColorObjectBtn";
			this->CheckColorObjectBtn->Size = System::Drawing::Size(68, 63);
			this->CheckColorObjectBtn->TabIndex = 50;
			this->CheckColorObjectBtn->UseVisualStyleBackColor = false;
			this->CheckColorObjectBtn->Click += gcnew System::EventHandler(this, &MyForm::CheckColorObjectBtn_Click);
			// 
			// SvImg
			// 
			this->SvImg->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(134)), static_cast<System::Int32>(static_cast<System::Byte>(185)),
				static_cast<System::Int32>(static_cast<System::Byte>(176)));
			this->SvImg->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"SvImg.BackgroundImage")));
			this->SvImg->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->SvImg->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->SvImg->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->SvImg->Location = System::Drawing::Point(84, 33);
			this->SvImg->Name = L"SvImg";
			this->SvImg->Size = System::Drawing::Size(70, 64);
			this->SvImg->TabIndex = 9;
			this->SvImg->UseVisualStyleBackColor = false;
			this->SvImg->Click += gcnew System::EventHandler(this, &MyForm::SvImg_Click);
			// 
			// ClrImg
			// 
			this->ClrImg->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(134)), static_cast<System::Int32>(static_cast<System::Byte>(185)),
				static_cast<System::Int32>(static_cast<System::Byte>(176)));
			this->ClrImg->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"ClrImg.BackgroundImage")));
			this->ClrImg->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClrImg->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ClrImg->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->ClrImg->Location = System::Drawing::Point(160, 35);
			this->ClrImg->Name = L"ClrImg";
			this->ClrImg->Size = System::Drawing::Size(70, 62);
			this->ClrImg->TabIndex = 10;
			this->ClrImg->UseVisualStyleBackColor = false;
			this->ClrImg->Click += gcnew System::EventHandler(this, &MyForm::button11_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label8->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label8->Location = System::Drawing::Point(271, 18);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(0, 18);
			this->label8->TabIndex = 47;
			// 
			// AdaptiveBinary
			// 
			this->AdaptiveBinary->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AdaptiveBinary->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"AdaptiveBinary.BackgroundImage")));
			this->AdaptiveBinary->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->AdaptiveBinary->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AdaptiveBinary->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AdaptiveBinary->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AdaptiveBinary->Location = System::Drawing::Point(16, 202);
			this->AdaptiveBinary->Name = L"AdaptiveBinary";
			this->AdaptiveBinary->Size = System::Drawing::Size(68, 63);
			this->AdaptiveBinary->TabIndex = 48;
			this->AdaptiveBinary->UseVisualStyleBackColor = false;
			this->AdaptiveBinary->Click += gcnew System::EventHandler(this, &MyForm::AdaptiveBinary_Click);
			// 
			// OptnPnl1
			// 
			this->OptnPnl1->AutoSizeMode = System::Windows::Forms::AutoSizeMode::GrowAndShrink;
			this->OptnPnl1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->OptnPnl1->Controls->Add(this->panel10);
			this->OptnPnl1->Controls->Add(this->panel16);
			this->OptnPnl1->Controls->Add(this->panel15);
			this->OptnPnl1->Controls->Add(this->panel14);
			this->OptnPnl1->Controls->Add(this->panel13);
			this->OptnPnl1->Controls->Add(this->panel11);
			this->OptnPnl1->Controls->Add(this->label8);
			this->OptnPnl1->Controls->Add(this->panel1);
			this->OptnPnl1->Location = System::Drawing::Point(-6, 0);
			this->OptnPnl1->Name = L"OptnPnl1";
			this->OptnPnl1->Size = System::Drawing::Size(676, 947);
			this->OptnPnl1->TabIndex = 0;
			this->OptnPnl1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::OptnPnl1_Paint);
			// 
			// panel10
			// 
			this->panel10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel10->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel10->Controls->Add(this->label33);
			this->panel10->Controls->Add(this->label49);
			this->panel10->Controls->Add(this->button31);
			this->panel10->Controls->Add(this->panel22);
			this->panel10->Controls->Add(this->button23);
			this->panel10->Controls->Add(this->label59);
			this->panel10->Controls->Add(this->button28);
			this->panel10->Controls->Add(this->label58);
			this->panel10->Controls->Add(this->textBox1);
			this->panel10->Controls->Add(this->textBox2);
			this->panel10->Controls->Add(this->label56);
			this->panel10->Controls->Add(this->button27);
			this->panel10->Controls->Add(this->label57);
			this->panel10->Controls->Add(this->button26);
			this->panel10->Controls->Add(this->button25);
			this->panel10->Controls->Add(this->label48);
			this->panel10->Controls->Add(this->label55);
			this->panel10->Controls->Add(this->button24);
			this->panel10->Controls->Add(this->label46);
			this->panel10->Controls->Add(this->label43);
			this->panel10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel10->Location = System::Drawing::Point(265, 539);
			this->panel10->Name = L"panel10";
			this->panel10->Size = System::Drawing::Size(393, 386);
			this->panel10->TabIndex = 55;
			this->panel10->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel10_Paint);
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Font = (gcnew System::Drawing::Font(L"Aquire", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label33->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label33->Location = System::Drawing::Point(31, 10);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(56, 17);
			this->label33->TabIndex = 54;
			this->label33->Text = L"SEEK";
			this->label33->Click += gcnew System::EventHandler(this, &MyForm::label33_Click);
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label49->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label49->Location = System::Drawing::Point(195, 78);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(21, 18);
			this->label49->TabIndex = 77;
			this->label49->Text = L"Y";
			// 
			// button31
			// 
			this->button31->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button31->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button31.BackgroundImage")));
			this->button31->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button31->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button31->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button31->Location = System::Drawing::Point(27, 30);
			this->button31->Name = L"button31";
			this->button31->Size = System::Drawing::Size(68, 63);
			this->button31->TabIndex = 71;
			this->button31->UseVisualStyleBackColor = false;
			this->button31->Click += gcnew System::EventHandler(this, &MyForm::button31_Click);
			// 
			// panel22
			// 
			this->panel22->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel22->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel22->Controls->Add(this->label60);
			this->panel22->Controls->Add(this->button30);
			this->panel22->Controls->Add(this->textBox9);
			this->panel22->Controls->Add(this->textBox10);
			this->panel22->Controls->Add(this->button29);
			this->panel22->Controls->Add(this->textBox11);
			this->panel22->Controls->Add(this->textBox8);
			this->panel22->Controls->Add(this->textBox7);
			this->panel22->Controls->Add(this->textBox6);
			this->panel22->Controls->Add(this->textBox5);
			this->panel22->Controls->Add(this->textBox4);
			this->panel22->Controls->Add(this->textBox3);
			this->panel22->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel22->Location = System::Drawing::Point(198, 128);
			this->panel22->Name = L"panel22";
			this->panel22->Size = System::Drawing::Size(195, 258);
			this->panel22->TabIndex = 87;
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label60->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label60->Location = System::Drawing::Point(5, 11);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(152, 18);
			this->label60->TabIndex = 88;
			this->label60->Text = L"MANUAL MATRIX";
			// 
			// button30
			// 
			this->button30->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button30->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button30->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button30->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->button30->Location = System::Drawing::Point(68, 211);
			this->button30->Name = L"button30";
			this->button30->Size = System::Drawing::Size(68, 30);
			this->button30->TabIndex = 16;
			this->button30->Text = L"APPLY";
			this->button30->UseVisualStyleBackColor = false;
			this->button30->Click += gcnew System::EventHandler(this, &MyForm::button30_Click);
			// 
			// textBox9
			// 
			this->textBox9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox9->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox9->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox9->Location = System::Drawing::Point(126, 144);
			this->textBox9->Name = L"textBox9";
			this->textBox9->Size = System::Drawing::Size(53, 42);
			this->textBox9->TabIndex = 72;
			this->textBox9->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox9->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox9_TextChanged);
			// 
			// textBox10
			// 
			this->textBox10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox10->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox10->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox10->Location = System::Drawing::Point(68, 144);
			this->textBox10->Name = L"textBox10";
			this->textBox10->Size = System::Drawing::Size(53, 42);
			this->textBox10->TabIndex = 71;
			this->textBox10->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox10->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox10_TextChanged);
			// 
			// button29
			// 
			this->button29->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button29.BackgroundImage")));
			this->button29->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button29->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button29->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button29->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button29->Location = System::Drawing::Point(142, 209);
			this->button29->Name = L"button29";
			this->button29->Size = System::Drawing::Size(40, 36);
			this->button29->TabIndex = 78;
			this->button29->UseVisualStyleBackColor = false;
			this->button29->Click += gcnew System::EventHandler(this, &MyForm::button29_Click);
			// 
			// textBox11
			// 
			this->textBox11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox11->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox11->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox11->Location = System::Drawing::Point(10, 144);
			this->textBox11->Name = L"textBox11";
			this->textBox11->Size = System::Drawing::Size(53, 42);
			this->textBox11->TabIndex = 70;
			this->textBox11->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox11->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox11_TextChanged);
			// 
			// textBox8
			// 
			this->textBox8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox8->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox8->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox8->Location = System::Drawing::Point(126, 97);
			this->textBox8->Name = L"textBox8";
			this->textBox8->Size = System::Drawing::Size(53, 42);
			this->textBox8->TabIndex = 69;
			this->textBox8->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox8->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox8_TextChanged);
			// 
			// textBox7
			// 
			this->textBox7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox7->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox7->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox7->Location = System::Drawing::Point(68, 97);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(53, 42);
			this->textBox7->TabIndex = 68;
			this->textBox7->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox7->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox7_TextChanged);
			// 
			// textBox6
			// 
			this->textBox6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox6->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox6->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox6->Location = System::Drawing::Point(11, 97);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(53, 42);
			this->textBox6->TabIndex = 67;
			this->textBox6->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox6->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox6_TextChanged);
			// 
			// textBox5
			// 
			this->textBox5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox5->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox5->Location = System::Drawing::Point(126, 49);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(53, 42);
			this->textBox5->TabIndex = 66;
			this->textBox5->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox5->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox5_TextChanged);
			// 
			// textBox4
			// 
			this->textBox4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox4->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox4->Location = System::Drawing::Point(68, 49);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(53, 42);
			this->textBox4->TabIndex = 65;
			this->textBox4->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox4->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox4_TextChanged);
			// 
			// textBox3
			// 
			this->textBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Aquire", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox3->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox3->Location = System::Drawing::Point(10, 49);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(53, 42);
			this->textBox3->TabIndex = 64;
			this->textBox3->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox3->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox3_TextChanged);
			// 
			// button23
			// 
			this->button23->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button23->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button23->ForeColor = System::Drawing::Color::White;
			this->button23->Location = System::Drawing::Point(309, 83);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(73, 35);
			this->button23->TabIndex = 75;
			this->button23->Text = L"CHECK";
			this->button23->UseVisualStyleBackColor = true;
			this->button23->Click += gcnew System::EventHandler(this, &MyForm::button23_Click);
			// 
			// label59
			// 
			this->label59->AutoSize = true;
			this->label59->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label59->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label59->Location = System::Drawing::Point(3, 357);
			this->label59->Name = L"label59";
			this->label59->Size = System::Drawing::Size(81, 18);
			this->label59->TabIndex = 86;
			this->label59->Text = L"EMBOSS";
			// 
			// button28
			// 
			this->button28->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button28->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button28.BackgroundImage")));
			this->button28->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button28->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button28->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button28->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button28->Location = System::Drawing::Point(15, 291);
			this->button28->Name = L"button28";
			this->button28->Size = System::Drawing::Size(68, 63);
			this->button28->TabIndex = 85;
			this->button28->UseVisualStyleBackColor = false;
			this->button28->Click += gcnew System::EventHandler(this, &MyForm::button28_Click);
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label58->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label58->Location = System::Drawing::Point(113, 270);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(66, 18);
			this->label58->TabIndex = 84;
			this->label58->Text = L"MEAN ";
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox1->Location = System::Drawing::Point(198, 58);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(81, 19);
			this->textBox1->TabIndex = 73;
			this->textBox1->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Aquire", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox2->ForeColor = System::Drawing::SystemColors::InactiveBorder;
			this->textBox2->Location = System::Drawing::Point(198, 99);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(81, 19);
			this->textBox2->TabIndex = 74;
			this->textBox2->TextAlign = System::Windows::Forms::HorizontalAlignment::Center;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox2_TextChanged);
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label56->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label56->Location = System::Drawing::Point(15, 184);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(99, 18);
			this->label56->TabIndex = 80;
			this->label56->Text = L"GAUSSIAN";
			// 
			// button27
			// 
			this->button27->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button27->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button27.BackgroundImage")));
			this->button27->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button27->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button27->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button27->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button27->Location = System::Drawing::Point(110, 204);
			this->button27->Name = L"button27";
			this->button27->Size = System::Drawing::Size(68, 63);
			this->button27->TabIndex = 83;
			this->button27->UseVisualStyleBackColor = false;
			this->button27->Click += gcnew System::EventHandler(this, &MyForm::button27_Click);
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label57->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label57->Location = System::Drawing::Point(98, 357);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(93, 18);
			this->label57->TabIndex = 82;
			this->label57->Text = L"SHARPEN";
			// 
			// button26
			// 
			this->button26->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button26->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button26.BackgroundImage")));
			this->button26->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button26->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button26->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button26->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button26->Location = System::Drawing::Point(110, 291);
			this->button26->Name = L"button26";
			this->button26->Size = System::Drawing::Size(68, 63);
			this->button26->TabIndex = 81;
			this->button26->UseVisualStyleBackColor = false;
			this->button26->Click += gcnew System::EventHandler(this, &MyForm::button26_Click);
			// 
			// button25
			// 
			this->button25->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button25->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button25.BackgroundImage")));
			this->button25->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button25->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button25->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button25->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button25->Location = System::Drawing::Point(27, 118);
			this->button25->Name = L"button25";
			this->button25->Size = System::Drawing::Size(68, 63);
			this->button25->TabIndex = 79;
			this->button25->UseVisualStyleBackColor = false;
			this->button25->Click += gcnew System::EventHandler(this, &MyForm::button25_Click_1);
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label48->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label48->Location = System::Drawing::Point(195, 38);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(21, 18);
			this->label48->TabIndex = 76;
			this->label48->Text = L"X";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label55->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label55->Location = System::Drawing::Point(15, 270);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(80, 18);
			this->label55->TabIndex = 63;
			this->label55->Text = L"SMOOTH";
			// 
			// button24
			// 
			this->button24->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button24->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button24.BackgroundImage")));
			this->button24->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button24->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button24->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button24->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button24->Location = System::Drawing::Point(15, 204);
			this->button24->Name = L"button24";
			this->button24->Size = System::Drawing::Size(68, 63);
			this->button24->TabIndex = 78;
			this->button24->UseVisualStyleBackColor = false;
			this->button24->Click += gcnew System::EventHandler(this, &MyForm::button24_Click);
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label46->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label46->Location = System::Drawing::Point(8, 97);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(135, 18);
			this->label46->TabIndex = 63;
			this->label46->Text = L"CONVOLUTION";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label43->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label43->Location = System::Drawing::Point(195, 12);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(130, 18);
			this->label43->TabIndex = 63;
			this->label43->Text = L"TRANSLATION";
			// 
			// panel16
			// 
			this->panel16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel16->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel16->Controls->Add(this->label34);
			this->panel16->Controls->Add(this->label32);
			this->panel16->Controls->Add(this->label31);
			this->panel16->Controls->Add(this->label30);
			this->panel16->Controls->Add(this->QtBtn);
			this->panel16->Controls->Add(this->SlctBtn);
			this->panel16->Controls->Add(this->ClrImg);
			this->panel16->Controls->Add(this->SvImg);
			this->panel16->Location = System::Drawing::Point(265, 10);
			this->panel16->Name = L"panel16";
			this->panel16->Size = System::Drawing::Size(393, 112);
			this->panel16->TabIndex = 51;
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label34->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label34->Location = System::Drawing::Point(254, 12);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(41, 15);
			this->label34->TabIndex = 55;
			this->label34->Text = L"EXIT";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label32->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label32->Location = System::Drawing::Point(166, 11);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(61, 15);
			this->label32->TabIndex = 53;
			this->label32->Text = L"CLEAR";
			this->label32->Click += gcnew System::EventHandler(this, &MyForm::label32_Click);
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label31->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label31->Location = System::Drawing::Point(98, 11);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(45, 15);
			this->label31->TabIndex = 52;
			this->label31->Text = L"SAVE";
			this->label31->Click += gcnew System::EventHandler(this, &MyForm::label31_Click);
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label30->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label30->Location = System::Drawing::Point(11, 12);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(73, 15);
			this->label30->TabIndex = 51;
			this->label30->Text = L"SELECT ";
			this->label30->Click += gcnew System::EventHandler(this, &MyForm::label30_Click);
			// 
			// panel15
			// 
			this->panel15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel15->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel15->Controls->Add(this->label61);
			this->panel15->Controls->Add(this->button17);
			this->panel15->Controls->Add(this->button21);
			this->panel15->Controls->Add(this->button22);
			this->panel15->Controls->Add(this->label47);
			this->panel15->Controls->Add(this->label45);
			this->panel15->Controls->Add(this->trackBar2);
			this->panel15->Controls->Add(this->button16);
			this->panel15->Controls->Add(this->button18);
			this->panel15->Controls->Add(this->button19);
			this->panel15->Controls->Add(this->button15);
			this->panel15->Location = System::Drawing::Point(378, 128);
			this->panel15->Name = L"panel15";
			this->panel15->Size = System::Drawing::Size(280, 405);
			this->panel15->TabIndex = 54;
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label61->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label61->Location = System::Drawing::Point(9, 11);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(190, 18);
			this->label61->TabIndex = 63;
			this->label61->Text = L"PHOTO ORIENTATION";
			// 
			// button17
			// 
			this->button17->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button17.BackgroundImage")));
			this->button17->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button17->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button17->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button17->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button17->Location = System::Drawing::Point(237, 64);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(32, 31);
			this->button17->TabIndex = 65;
			this->button17->UseVisualStyleBackColor = false;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm::button17_Click);
			// 
			// button21
			// 
			this->button21->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button21->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button21.BackgroundImage")));
			this->button21->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button21->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button21->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button21->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button21->Location = System::Drawing::Point(38, 336);
			this->button21->Name = L"button21";
			this->button21->Size = System::Drawing::Size(68, 63);
			this->button21->TabIndex = 72;
			this->button21->UseVisualStyleBackColor = false;
			this->button21->Click += gcnew System::EventHandler(this, &MyForm::button21_Click);
			// 
			// button22
			// 
			this->button22->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button22->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button22.BackgroundImage")));
			this->button22->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button22->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button22->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button22->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button22->Location = System::Drawing::Point(162, 336);
			this->button22->Name = L"button22";
			this->button22->Size = System::Drawing::Size(68, 63);
			this->button22->TabIndex = 71;
			this->button22->UseVisualStyleBackColor = false;
			this->button22->Click += gcnew System::EventHandler(this, &MyForm::button22_Click);
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Font = (gcnew System::Drawing::Font(L"Aquire", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label47->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label47->Location = System::Drawing::Point(61, 94);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(127, 15);
			this->label47->TabIndex = 64;
			this->label47->Text = L"------------------------";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label45->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label45->Location = System::Drawing::Point(9, 298);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(190, 18);
			this->label45->TabIndex = 70;
			this->label45->Text = L"BINARY PROJECTION";
			// 
			// trackBar2
			// 
			this->trackBar2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->trackBar2->LargeChange = 20;
			this->trackBar2->Location = System::Drawing::Point(12, 53);
			this->trackBar2->Maximum = 360;
			this->trackBar2->Minimum = -360;
			this->trackBar2->Name = L"trackBar2";
			this->trackBar2->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar2->Size = System::Drawing::Size(219, 56);
			this->trackBar2->TabIndex = 65;
			this->trackBar2->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar2_Scroll_1);
			// 
			// button16
			// 
			this->button16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button16->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button16.BackgroundImage")));
			this->button16->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button16->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button16->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button16->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button16->Location = System::Drawing::Point(162, 214);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(68, 63);
			this->button16->TabIndex = 64;
			this->button16->UseVisualStyleBackColor = false;
			this->button16->Click += gcnew System::EventHandler(this, &MyForm::button16_Click);
			// 
			// button18
			// 
			this->button18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button18->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button18.BackgroundImage")));
			this->button18->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button18->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button18->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button18->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button18->Location = System::Drawing::Point(163, 130);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(68, 63);
			this->button18->TabIndex = 66;
			this->button18->UseVisualStyleBackColor = false;
			this->button18->Click += gcnew System::EventHandler(this, &MyForm::button18_Click);
			// 
			// button19
			// 
			this->button19->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button19->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button19.BackgroundImage")));
			this->button19->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button19->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button19->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button19->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button19->Location = System::Drawing::Point(41, 128);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(68, 63);
			this->button19->TabIndex = 67;
			this->button19->UseVisualStyleBackColor = false;
			this->button19->Click += gcnew System::EventHandler(this, &MyForm::button19_Click);
			// 
			// button15
			// 
			this->button15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button15->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button15.BackgroundImage")));
			this->button15->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->button15->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button15->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button15->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button15->Location = System::Drawing::Point(38, 214);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(68, 63);
			this->button15->TabIndex = 51;
			this->button15->UseVisualStyleBackColor = false;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm::button15_Click_2);
			// 
			// panel14
			// 
			this->panel14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel14->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel14->Controls->Add(this->label44);
			this->panel14->Controls->Add(this->BWBtn);
			this->panel14->Controls->Add(this->label29);
			this->panel14->Controls->Add(this->label28);
			this->panel14->Controls->Add(this->button20);
			this->panel14->Controls->Add(this->GrySclBtn);
			this->panel14->Controls->Add(this->AdaptiveBinary);
			this->panel14->Controls->Add(this->label26);
			this->panel14->Location = System::Drawing::Point(265, 128);
			this->panel14->Name = L"panel14";
			this->panel14->Size = System::Drawing::Size(107, 405);
			this->panel14->TabIndex = 51;
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label44->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label44->Location = System::Drawing::Point(17, 366);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(70, 18);
			this->label44->TabIndex = 70;
			this->label44->Text = L"GRAPH";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label29->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label29->Location = System::Drawing::Point(17, 70);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(57, 18);
			this->label29->TabIndex = 53;
			this->label29->Text = L"GRAY";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label28->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label28->Location = System::Drawing::Point(13, 268);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(70, 18);
			this->label28->TabIndex = 52;
			this->label28->Text = L"ADAPT";
			// 
			// button20
			// 
			this->button20->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button20->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button20.BackgroundImage")));
			this->button20->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button20->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button20->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button20->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button20->Location = System::Drawing::Point(16, 298);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(68, 63);
			this->button20->TabIndex = 69;
			this->button20->UseVisualStyleBackColor = false;
			this->button20->Click += gcnew System::EventHandler(this, &MyForm::button20_Click);
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label26->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label26->Location = System::Drawing::Point(15, 170);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(59, 18);
			this->label26->TabIndex = 51;
			this->label26->Text = L"B / W";
			// 
			// panel13
			// 
			this->panel13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->panel13->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel13->Controls->Add(this->label40);
			this->panel13->Controls->Add(this->label24);
			this->panel13->Controls->Add(this->button14);
			this->panel13->Controls->Add(this->label38);
			this->panel13->Controls->Add(this->label21);
			this->panel13->Controls->Add(this->label39);
			this->panel13->Controls->Add(this->button13);
			this->panel13->Controls->Add(this->label35);
			this->panel13->Controls->Add(this->label20);
			this->panel13->Controls->Add(this->label22);
			this->panel13->Controls->Add(this->AreaObjctBtn);
			this->panel13->Controls->Add(this->label19);
			this->panel13->Controls->Add(this->CntrObjctBtn);
			this->panel13->Controls->Add(this->button11);
			this->panel13->Controls->Add(this->label25);
			this->panel13->Controls->Add(this->CntrImgBtn);
			this->panel13->Controls->Add(this->AreaImgBtn);
			this->panel13->Controls->Add(this->label27);
			this->panel13->Controls->Add(this->label18);
			this->panel13->Controls->Add(this->button12);
			this->panel13->Controls->Add(this->label23);
			this->panel13->Location = System::Drawing::Point(9, 387);
			this->panel13->Name = L"panel13";
			this->panel13->Size = System::Drawing::Size(252, 539);
			this->panel13->TabIndex = 51;
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Font = (gcnew System::Drawing::Font(L"Aquire", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label40->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label40->Location = System::Drawing::Point(4, 402);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(129, 17);
			this->label40->TabIndex = 62;
			this->label40->Text = L"COORDINATES";
			this->label40->Click += gcnew System::EventHandler(this, &MyForm::label40_Click);
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label24->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label24->Location = System::Drawing::Point(4, 161);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(98, 18);
			this->label24->TabIndex = 60;
			this->label24->Text = L"CENTROID";
			this->label24->Click += gcnew System::EventHandler(this, &MyForm::label24_Click);
			// 
			// button14
			// 
			this->button14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button14->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button14.BackgroundImage")));
			this->button14->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button14->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button14->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button14->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button14->Location = System::Drawing::Point(142, 422);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(68, 63);
			this->button14->TabIndex = 53;
			this->button14->UseVisualStyleBackColor = false;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::button14_Click);
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label38->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label38->Location = System::Drawing::Point(139, 488);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(81, 18);
			this->label38->TabIndex = 54;
			this->label38->Text = L"OBJECT";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label21->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label21->Location = System::Drawing::Point(4, 38);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(70, 18);
			this->label21->TabIndex = 55;
			this->label21->Text = L"AREA ";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label39->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label39->Location = System::Drawing::Point(4, 285);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(129, 18);
			this->label39->TabIndex = 61;
			this->label39->Text = L"RECEPTACLE";
			// 
			// button13
			// 
			this->button13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button13->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button13.BackgroundImage")));
			this->button13->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button13->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button13->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button13->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button13->Location = System::Drawing::Point(29, 422);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(68, 63);
			this->button13->TabIndex = 51;
			this->button13->UseVisualStyleBackColor = false;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm::button13_Click);
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label35->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label35->Location = System::Drawing::Point(33, 488);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(68, 18);
			this->label35->TabIndex = 52;
			this->label35->Text = L"PHOTO";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label20->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label20->Location = System::Drawing::Point(139, 125);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(81, 18);
			this->label20->TabIndex = 54;
			this->label20->Text = L"OBJECT";
			this->label20->Click += gcnew System::EventHandler(this, &MyForm::label20_Click);
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label22->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label22->Location = System::Drawing::Point(139, 248);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(81, 18);
			this->label22->TabIndex = 59;
			this->label22->Text = L"OBJECT";
			// 
			// AreaObjctBtn
			// 
			this->AreaObjctBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AreaObjctBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"AreaObjctBtn.BackgroundImage")));
			this->AreaObjctBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->AreaObjctBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AreaObjctBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AreaObjctBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AreaObjctBtn->Location = System::Drawing::Point(142, 59);
			this->AreaObjctBtn->Name = L"AreaObjctBtn";
			this->AreaObjctBtn->Size = System::Drawing::Size(68, 63);
			this->AreaObjctBtn->TabIndex = 53;
			this->AreaObjctBtn->UseVisualStyleBackColor = false;
			this->AreaObjctBtn->Click += gcnew System::EventHandler(this, &MyForm::button11_Click_2);
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label19->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label19->Location = System::Drawing::Point(3, 9);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(134, 18);
			this->label19->TabIndex = 51;
			this->label19->Text = L"GEOMETRICS ";
			// 
			// CntrObjctBtn
			// 
			this->CntrObjctBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CntrObjctBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"CntrObjctBtn.BackgroundImage")));
			this->CntrObjctBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->CntrObjctBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CntrObjctBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CntrObjctBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CntrObjctBtn->Location = System::Drawing::Point(142, 182);
			this->CntrObjctBtn->Name = L"CntrObjctBtn";
			this->CntrObjctBtn->Size = System::Drawing::Size(68, 63);
			this->CntrObjctBtn->TabIndex = 58;
			this->CntrObjctBtn->UseVisualStyleBackColor = false;
			this->CntrObjctBtn->Click += gcnew System::EventHandler(this, &MyForm::CntrObjctBtn_Click);
			// 
			// button11
			// 
			this->button11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button11->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button11.BackgroundImage")));
			this->button11->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button11->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button11->Location = System::Drawing::Point(142, 306);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(68, 63);
			this->button11->TabIndex = 50;
			this->button11->UseVisualStyleBackColor = false;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button11_Click_3);
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label25->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label25->Location = System::Drawing::Point(139, 372);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(81, 18);
			this->label25->TabIndex = 50;
			this->label25->Text = L"OBJECT";
			this->label25->Click += gcnew System::EventHandler(this, &MyForm::label25_Click);
			// 
			// CntrImgBtn
			// 
			this->CntrImgBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CntrImgBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"CntrImgBtn.BackgroundImage")));
			this->CntrImgBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->CntrImgBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->CntrImgBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->CntrImgBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->CntrImgBtn->Location = System::Drawing::Point(33, 182);
			this->CntrImgBtn->Name = L"CntrImgBtn";
			this->CntrImgBtn->Size = System::Drawing::Size(68, 63);
			this->CntrImgBtn->TabIndex = 56;
			this->CntrImgBtn->UseVisualStyleBackColor = false;
			this->CntrImgBtn->Click += gcnew System::EventHandler(this, &MyForm::CntrImgBtn_Click);
			// 
			// AreaImgBtn
			// 
			this->AreaImgBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AreaImgBtn->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"AreaImgBtn.BackgroundImage")));
			this->AreaImgBtn->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->AreaImgBtn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->AreaImgBtn->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->AreaImgBtn->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->AreaImgBtn->Location = System::Drawing::Point(30, 59);
			this->AreaImgBtn->Name = L"AreaImgBtn";
			this->AreaImgBtn->Size = System::Drawing::Size(68, 63);
			this->AreaImgBtn->TabIndex = 51;
			this->AreaImgBtn->UseVisualStyleBackColor = false;
			this->AreaImgBtn->Click += gcnew System::EventHandler(this, &MyForm::AreaImgBtn_Click);
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label27->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label27->Location = System::Drawing::Point(34, 372);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(68, 18);
			this->label27->TabIndex = 49;
			this->label27->Text = L"PHOTO";
			this->label27->Click += gcnew System::EventHandler(this, &MyForm::label27_Click);
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label18->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label18->Location = System::Drawing::Point(29, 125);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(68, 18);
			this->label18->TabIndex = 52;
			this->label18->Text = L"PHOTO";
			this->label18->Click += gcnew System::EventHandler(this, &MyForm::label18_Click);
			// 
			// button12
			// 
			this->button12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button12->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button12.BackgroundImage")));
			this->button12->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->button12->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button12->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button12->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(38)),
				static_cast<System::Int32>(static_cast<System::Byte>(48)));
			this->button12->Location = System::Drawing::Point(34, 306);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(68, 63);
			this->button12->TabIndex = 49;
			this->button12->UseVisualStyleBackColor = false;
			this->button12->Click += gcnew System::EventHandler(this, &MyForm::button12_Click);
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Font = (gcnew System::Drawing::Font(L"Aquire", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label23->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label23->Location = System::Drawing::Point(29, 248);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(68, 18);
			this->label23->TabIndex = 57;
			this->label23->Text = L"PHOTO";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label12->Location = System::Drawing::Point(15, 47);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(135, 20);
			this->label12->TabIndex = 50;
			this->label12->Text = L"* * * * * * * * *";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label13->Location = System::Drawing::Point(15, 77);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(135, 20);
			this->label13->TabIndex = 51;
			this->label13->Text = L"* * * * * * * * *";
			this->label13->Click += gcnew System::EventHandler(this, &MyForm::label13_Click);
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label14->Location = System::Drawing::Point(15, 184);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(135, 20);
			this->label14->TabIndex = 52;
			this->label14->Text = L"* * * * * * * * *";
			this->label14->Click += gcnew System::EventHandler(this, &MyForm::label14_Click);
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label15->Location = System::Drawing::Point(15, 112);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(135, 20);
			this->label15->TabIndex = 53;
			this->label15->Text = L"* * * * * * * * *";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label16->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label16->Location = System::Drawing::Point(15, 148);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(135, 20);
			this->label16->TabIndex = 54;
			this->label16->Text = L"* * * * * * * * *";
			this->label16->Click += gcnew System::EventHandler(this, &MyForm::label16_Click);
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label17->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label17->Location = System::Drawing::Point(15, 10);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(324, 20);
			this->label17->TabIndex = 55;
			this->label17->Text = L"* * * * * * * * * * * * * * * * * * * * * \r\n";
			this->label17->Click += gcnew System::EventHandler(this, &MyForm::label17_Click);
			// 
			// panel12
			// 
			this->panel12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel12->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel12->Controls->Add(this->label41);
			this->panel12->Controls->Add(this->label13);
			this->panel12->Controls->Add(this->label37);
			this->panel12->Controls->Add(this->label17);
			this->panel12->Controls->Add(this->label14);
			this->panel12->Controls->Add(this->label12);
			this->panel12->Controls->Add(this->label36);
			this->panel12->Controls->Add(this->label15);
			this->panel12->Controls->Add(this->label16);
			this->panel12->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel12->Location = System::Drawing::Point(1470, 437);
			this->panel12->Name = L"panel12";
			this->panel12->Size = System::Drawing::Size(408, 490);
			this->panel12->TabIndex = 56;
			this->panel12->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel12_Paint);
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label41->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label41->Location = System::Drawing::Point(15, 314);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(135, 20);
			this->label41->TabIndex = 58;
			this->label41->Text = L"* * * * * * * * *";
			this->label41->Click += gcnew System::EventHandler(this, &MyForm::label41_Click);
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label37->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label37->Location = System::Drawing::Point(15, 278);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(135, 20);
			this->label37->TabIndex = 57;
			this->label37->Text = L"* * * * * * * * *";
			this->label37->Click += gcnew System::EventHandler(this, &MyForm::label37_Click);
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label36->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label36->Location = System::Drawing::Point(15, 240);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(135, 20);
			this->label36->TabIndex = 56;
			this->label36->Text = L"* * * * * * * * *";
			this->label36->Click += gcnew System::EventHandler(this, &MyForm::label36_Click);
			// 
			// panel19
			// 
			this->panel19->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel19->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel19.BackgroundImage")));
			this->panel19->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel19->Location = System::Drawing::Point(677, 33);
			this->panel19->Name = L"panel19";
			this->panel19->Size = System::Drawing::Size(60, 55);
			this->panel19->TabIndex = 42;
			// 
			// panel18
			// 
			this->panel18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel18->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel18.BackgroundImage")));
			this->panel18->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel18->Location = System::Drawing::Point(677, 95);
			this->panel18->Name = L"panel18";
			this->panel18->Size = System::Drawing::Size(60, 55);
			this->panel18->TabIndex = 59;
			// 
			// trackBar3
			// 
			this->trackBar3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar3->Location = System::Drawing::Point(741, 101);
			this->trackBar3->Maximum = 100;
			this->trackBar3->Name = L"trackBar3";
			this->trackBar3->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar3->Size = System::Drawing::Size(261, 56);
			this->trackBar3->TabIndex = 58;
			this->trackBar3->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar3_Scroll_2);
			// 
			// panel20
			// 
			this->panel20->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel20->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel20.BackgroundImage")));
			this->panel20->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel20->Location = System::Drawing::Point(677, 158);
			this->panel20->Name = L"panel20";
			this->panel20->Size = System::Drawing::Size(60, 55);
			this->panel20->TabIndex = 61;
			// 
			// trackBar4
			// 
			this->trackBar4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar4->Location = System::Drawing::Point(741, 164);
			this->trackBar4->Maximum = 100;
			this->trackBar4->Name = L"trackBar4";
			this->trackBar4->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar4->Size = System::Drawing::Size(261, 56);
			this->trackBar4->TabIndex = 60;
			this->trackBar4->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar4_Scroll_1);
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->label42->Font = (gcnew System::Drawing::Font(L"Black Future", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label42->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label42->Location = System::Drawing::Point(676, 248);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(170, 18);
			this->label42->TabIndex = 62;
			this->label42->Text = L"P H O T O  S E G M E N T";
			// 
			// panel21
			// 
			this->panel21->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel21->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel21.BackgroundImage")));
			this->panel21->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->panel21->Location = System::Drawing::Point(679, 266);
			this->panel21->Name = L"panel21";
			this->panel21->Size = System::Drawing::Size(60, 55);
			this->panel21->TabIndex = 64;
			// 
			// trackBar5
			// 
			this->trackBar5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->trackBar5->LargeChange = 3;
			this->trackBar5->Location = System::Drawing::Point(743, 272);
			this->trackBar5->Maximum = 100;
			this->trackBar5->Name = L"trackBar5";
			this->trackBar5->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->trackBar5->Size = System::Drawing::Size(261, 56);
			this->trackBar5->TabIndex = 63;
			this->trackBar5->Scroll += gcnew System::EventHandler(this, &MyForm::trackBar5_Scroll_1);
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label50->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label50->Location = System::Drawing::Point(3, 9);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(345, 20);
			this->label50->TabIndex = 55;
			this->label50->Text = L"* * * * * * * * * * * * * * * * * * * * * * *";
			this->label50->Click += gcnew System::EventHandler(this, &MyForm::label50_Click);
			// 
			// panel17
			// 
			this->panel17->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->panel17->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel17->Controls->Add(this->label54);
			this->panel17->Controls->Add(this->label51);
			this->panel17->Controls->Add(this->pictureBox5);
			this->panel17->Controls->Add(this->label52);
			this->panel17->Controls->Add(this->label53);
			this->panel17->Controls->Add(this->label50);
			this->panel17->Controls->Add(this->pictureBox4);
			this->panel17->Controls->Add(this->pictureBox3);
			this->panel17->Location = System::Drawing::Point(1042, 437);
			this->panel17->Name = L"panel17";
			this->panel17->Size = System::Drawing::Size(408, 490);
			this->panel17->TabIndex = 59;
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label54->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label54->Location = System::Drawing::Point(259, 299);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(135, 20);
			this->label54->TabIndex = 59;
			this->label54->Text = L"* * * * * * * * *";
			this->label54->Click += gcnew System::EventHandler(this, &MyForm::label54_Click);
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label51->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label51->Location = System::Drawing::Point(259, 215);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(135, 20);
			this->label51->TabIndex = 61;
			this->label51->Text = L"* * * * * * * * *";
			this->label51->Click += gcnew System::EventHandler(this, &MyForm::label51_Click);
			// 
			// pictureBox5
			// 
			this->pictureBox5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->pictureBox5->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox5.BackgroundImage")));
			this->pictureBox5->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox5->Location = System::Drawing::Point(7, 338);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(251, 145);
			this->pictureBox5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox5->TabIndex = 68;
			this->pictureBox5->TabStop = false;
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label52->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label52->Location = System::Drawing::Point(259, 132);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(135, 20);
			this->label52->TabIndex = 60;
			this->label52->Text = L"* * * * * * * * *";
			this->label52->Click += gcnew System::EventHandler(this, &MyForm::label52_Click);
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Font = (gcnew System::Drawing::Font(L"Aquire", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label53->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label53->Location = System::Drawing::Point(259, 43);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(135, 20);
			this->label53->TabIndex = 59;
			this->label53->Text = L"* * * * * * * * *";
			this->label53->Click += gcnew System::EventHandler(this, &MyForm::label53_Click);
			// 
			// pictureBox4
			// 
			this->pictureBox4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->pictureBox4->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox4.BackgroundImage")));
			this->pictureBox4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox4->Location = System::Drawing::Point(7, 43);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(251, 145);
			this->pictureBox4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox4->TabIndex = 66;
			this->pictureBox4->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->pictureBox3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.BackgroundImage")));
			this->pictureBox3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox3->Location = System::Drawing::Point(7, 190);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(251, 145);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox3->TabIndex = 67;
			this->pictureBox3->TabStop = false;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(4)), static_cast<System::Int32>(static_cast<System::Byte>(20)),
				static_cast<System::Int32>(static_cast<System::Byte>(33)));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->ClientSize = System::Drawing::Size(1918, 939);
			this->Controls->Add(this->panel17);
			this->Controls->Add(this->panel21);
			this->Controls->Add(this->trackBar5);
			this->Controls->Add(this->label42);
			this->Controls->Add(this->panel20);
			this->Controls->Add(this->trackBar4);
			this->Controls->Add(this->panel18);
			this->Controls->Add(this->trackBar3);
			this->Controls->Add(this->panel19);
			this->Controls->Add(this->panel12);
			this->Controls->Add(this->ThresRst);
			this->Controls->Add(this->RstEnhanceAdjust);
			this->Controls->Add(this->RstrgbTrckBars);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->panel4);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->trackBar9);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->panel9);
			this->Controls->Add(this->trackBar8);
			this->Controls->Add(this->panel8);
			this->Controls->Add(this->trackBar7);
			this->Controls->Add(this->panel7);
			this->Controls->Add(this->panel6);
			this->Controls->Add(this->trackBar6);
			this->Controls->Add(this->panel5);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->Opacity);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->trackBar_Blue);
			this->Controls->Add(this->trackBar1);
			this->Controls->Add(this->trackBar_Green);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->trackBar_Red);
			this->Controls->Add(this->OptnPnl1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->ImeMode = System::Windows::Forms::ImeMode::Katakana;
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MVRVC";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Red))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Green))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_Blue))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Opacity))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar9))->EndInit();
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel11->ResumeLayout(false);
			this->panel11->PerformLayout();
			this->OptnPnl1->ResumeLayout(false);
			this->OptnPnl1->PerformLayout();
			this->panel10->ResumeLayout(false);
			this->panel10->PerformLayout();
			this->panel22->ResumeLayout(false);
			this->panel22->PerformLayout();
			this->panel16->ResumeLayout(false);
			this->panel16->PerformLayout();
			this->panel15->ResumeLayout(false);
			this->panel15->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar2))->EndInit();
			this->panel14->ResumeLayout(false);
			this->panel14->PerformLayout();
			this->panel13->ResumeLayout(false);
			this->panel13->PerformLayout();
			this->panel12->ResumeLayout(false);
			this->panel12->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar5))->EndInit();
			this->panel17->ResumeLayout(false);
			this->panel17->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	//Button is to execute where the original photo duplicates or resets the photo from the other picture box. If it presses the button without selecting an image from the "SELECT BUTTON", an error message occurs.
	private: System::Void ExctDsp_Click(System::Object^ sender, System::EventArgs^ e) {
		 // Check if pictureBox1 has an image
    if (pictureBox1->Image == nullptr) {
        MessageBox::Show("PICTURE IS EMPTY. NO IMAGE TO TRANSFER.", 
                         "PLEASE SELECT AN IMAGE!", 
                         MessageBoxButtons::OK, MessageBoxIcon::Error);
        return;
    }

    // Check if pictureBox2 already has an image
    if (pictureBox2->Image != nullptr) {
        MessageBox::Show("AN IMAGE IS ALREADY EXECUTED.", 
                         "OPERATION DENIED!", 
                         MessageBoxButtons::OK, MessageBoxIcon::Warning);
        return;
    }

    // Transfer the image from pictureBox1 to pictureBox2
    pictureBox2->Image = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	}

	private: System::Void BWBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		// This function converts the original image into BLACK AND WHITE (BINARY IMAGE)

		// Check if an image is loaded in pictureBox1
		if (pictureBox1->Image == nullptr) {
			// Display an error message if no image is found
			MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return; // Exit the function if no image is loaded
		}

		// Create a Bitmap object from the image in pictureBox1
		Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);

		// Get the width and height of the image
		int width = originalBitmap->Width;
		int height = originalBitmap->Height;

		// Lock the bitmap's bits to allow direct pixel manipulation
		System::Drawing::Imaging::BitmapData^ bmpData = originalBitmap->LockBits(
			System::Drawing::Rectangle(0, 0, width, height), // Lock entire image
			System::Drawing::Imaging::ImageLockMode::ReadWrite, // Allow reading and writing
			System::Drawing::Imaging::PixelFormat::Format24bppRgb // Use 24-bit color format (faster processing)
		);

		// Get the pointer to the bitmap's raw pixel data
		unsigned char* ptr = (unsigned char*)(void*)bmpData->Scan0;

		// Get the stride (number of bytes per row, including padding)
		int stride = bmpData->Stride;

		// Loop through each row (y-axis)
		for (int y = 0; y < height; y++) {
			// Get the pointer to the current row
			unsigned char* row = ptr + (y * stride);

			// Loop through each pixel in the row (x-axis)
			for (int x = 0; x < width; x++) {
				int index = x * 3; // Each pixel has 3 bytes (B, G, R format)

				// Convert the pixel to grayscale using the luminance formula:
				// Grayscale = 0.299 * Red + 0.587 * Green + 0.114 * Blue
				int grayValue = (int)(0.299 * row[index + 2] + 0.587 * row[index + 1] + 0.114 * row[index]);

				// Apply thresholding: If grayscale value is less than 128, set it to black (0), otherwise set it to white (255)
				unsigned char bwColor = (grayValue < 128) ? 0 : 255;

				// Set all three color channels (B, G, R) to the binary color (black or white)
				row[index] = bwColor;       // Blue channel
				row[index + 1] = bwColor;   // Green channel
				row[index + 2] = bwColor;   // Red channel
			}
		}

		// Unlock the bits of the image to apply the changes
		originalBitmap->UnlockBits(bmpData);

		// Display the black and white image in pictureBox2
		pictureBox2->Image = originalBitmap;
	}

	private: System::Void GrySclBtn_Click(System::Object^ sender, System::EventArgs^ e) { //This code if the execute the original image and converts it into grayscale mode

		// Check if an image is loaded in pictureBox1
		if (pictureBox1->Image == nullptr) { // nullptr means no image is loaded
			// Display an error message if no image is found
			MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return; // Exit the function if no image is loaded
		}

		// Create a Bitmap object from the image in pictureBox1
		Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);

		// Create a new blank grayscale bitmap with the same width and height as the original image
		// Using 24bpp RGB format since grayscale images can still be represented with 24 bits per pixel
		Bitmap^ grayBitmap = gcnew Bitmap(originalBitmap->Width, originalBitmap->Height, PixelFormat::Format24bppRgb);

		// Lock the bits of the original image for direct pixel manipulation
		BitmapData^ originalData = originalBitmap->LockBits(
			System::Drawing::Rectangle(0, 0, originalBitmap->Width, originalBitmap->Height),
			ImageLockMode::ReadOnly, // Lock for reading only
			PixelFormat::Format24bppRgb // Ensure consistent pixel format
		);

		// Lock the bits of the grayscale image for writing
		BitmapData^ grayData = grayBitmap->LockBits(
			System::Drawing::Rectangle(0, 0, grayBitmap->Width, grayBitmap->Height),
			ImageLockMode::WriteOnly, // Lock for writing only
			PixelFormat::Format24bppRgb // Ensure consistent pixel format
		);

		// Get the stride (number of bytes per row including padding) of the original image
		int stride = originalData->Stride;

		// Get pointers to the pixel data of both images (original and grayscale)
		unsigned char* originalPtr = (unsigned char*)(void*)originalData->Scan0; // Pointer to original image data
		unsigned char* grayPtr = (unsigned char*)(void*)grayData->Scan0; // Pointer to grayscale image data

		// Loop through each row (y-axis)
		for (int y = 0; y < originalBitmap->Height; y++) {
			// Loop through each column (x-axis)
			for (int x = 0; x < originalBitmap->Width; x++) {
				// Calculate the index in the byte array (each pixel has 3 bytes: Blue, Green, and Red)
				int index = y * stride + x * 3;

				// Extract the Blue, Green, and Red values from the original image
				unsigned char blue = originalPtr[index];
				unsigned char green = originalPtr[index + 1];
				unsigned char red = originalPtr[index + 2];

				// Convert the pixel to grayscale using the luminance formula:
				// Grayscale = 0.299 * Red + 0.587 * Green + 0.114 * Blue
				unsigned char gray = (unsigned char)(0.299 * red + 0.587 * green + 0.114 * blue);

				// Assign the grayscale value to all three color channels (R, G, B)
				grayPtr[index] = gray;       // Blue channel
				grayPtr[index + 1] = gray;   // Green channel
				grayPtr[index + 2] = gray;   // Red channel
			}
		}

		// Unlock the bits of both images after processing
		originalBitmap->UnlockBits(originalData);
		grayBitmap->UnlockBits(grayData);

		// Display the grayscale image in pictureBox2
		pictureBox2->Image = grayBitmap;
	}

		//This code is a button for a user to press and select the image inside the file manager.
	private: System::Void SlctBtn_Click(System::Object^ sender, System::EventArgs^ e) {
		OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog();
		openFileDialog1->Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp|All Files|*.*";
		openFileDialog1->Title = "Select an Image File";
		openFileDialog1->Multiselect = false;
		openFileDialog1->InitialDirectory = "C:\\Users\\RV\\Pictures\\Machine Vision";

		// Check if pictureBox1 already has an image
		if (pictureBox1->Image != nullptr) {
			MessageBox::Show("Please clear the current image before selecting a new one.",
				"Warning", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		}
		else if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			System::String^ filePath = openFileDialog1->FileName;

			if (System::IO::File::Exists(filePath)) {
				// Load image safely into PictureBox
				pictureBox1->Image = gcnew Bitmap(filePath);

				// Load image safely into PictureBox
				pictureBox2->Image = gcnew Bitmap(filePath);

				// Create a new Bitmap to avoid file locking issue
				originalBitmap = gcnew Bitmap(pictureBox1->Image);

				// Create a new Bitmap to avoid file locking issue
				originalBitmap = gcnew Bitmap(pictureBox2->Image);
			}
			else {
				MessageBox::Show("File does not exist!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
		}
	}

private: System::Void pictureBox2_Click(System::Object^ sender, System::EventArgs^ e) {
}


private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void panel1_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
}




private: System::Void trackBar1_Scroll(System::Object^ sender, System::EventArgs^ e) {
	// This function updates the black and white image threshold dynamically using a trackbar

		// Check if an image is loaded
	if (originalBitmap == nullptr) {
		// Show an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}

	// Get the current position of the trackbar
	int scrollPosition = trackBar1->Value;

	// Convert the trackbar position to a threshold value between 0 and 255
	int threshold = (scrollPosition == trackBar1->Maximum) ? 255 : (255 * scrollPosition / trackBar1->Maximum);

	// Create a copy of the original image to apply thresholding
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(originalBitmap);

	// Lock the bitmap for direct pixel access
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(
		System::Drawing::Rectangle(0, 0, modifiedBitmap->Width, modifiedBitmap->Height), // Lock entire image
		System::Drawing::Imaging::ImageLockMode::ReadWrite, // Allow reading and writing
		System::Drawing::Imaging::PixelFormat::Format24bppRgb // 24-bit color format (fast processing)
	);

	// Get the stride (number of bytes per row including padding)
	int stride = bmpData->Stride;

	// Get the pointer to the bitmap's raw pixel data
	unsigned char* ptr = (unsigned char*)(void*)bmpData->Scan0;

	// Loop through each row (y-axis)
	for (int y = 0; y < modifiedBitmap->Height; y++) {
		// Loop through each pixel in the row (x-axis)
		for (int x = 0; x < modifiedBitmap->Width; x++) {
			int index = y * stride + x * 3; // Each pixel has 3 bytes (B, G, R format)

			// Extract the Blue, Green, and Red values from the image
			int blue = ptr[index];
			int green = ptr[index + 1];
			int red = ptr[index + 2];

			// Convert the pixel to grayscale using the luminance formula:
			// Grayscale = 0.299 * Red + 0.587 * Green + 0.114 * Blue
			int grayValue = (int)(0.299 * red + 0.587 * green + 0.114 * blue);

			// Apply thresholding: If grayscale value is below the threshold, set pixel to black (0), otherwise set it to white (255)
			unsigned char newPixelValue = (grayValue < threshold) ? 0 : 255;

			// Assign the new black and white value to all three color channels (R, G, B)
			ptr[index] = newPixelValue;      // Blue
			ptr[index + 1] = newPixelValue;  // Green
			ptr[index + 2] = newPixelValue;  // Red
		}
	}

	// Unlock the bitmap after processing
	modifiedBitmap->UnlockBits(bmpData);

	// Display the thresholded black and white image in pictureBox2
	pictureBox2->Image = modifiedBitmap;
}



private: System::Void LightThreshold_Scroll(System::Object^ sender, System::EventArgs^ e) {
	
}


private: System::Void trackBar3_Scroll_1(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded
	if (originalBitmap == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	cv::Mat originalMat;
	BitmapToMat(originalBitmap, originalMat); // Assuming BitmapToMat takes cv::Mat&

	if (originalMat.empty()) return;

	cv::Mat gray, binaryMask, segmentedMat;
	cv::cvtColor(originalMat, gray, cv::COLOR_BGR2GRAY);

	// Apply adaptive thresholding to detect all object pixels
	cv::adaptiveThreshold(gray, binaryMask, 255, cv::ADAPTIVE_THRESH_GAUSSIAN_C, cv::THRESH_BINARY_INV, 11, 2);

	// Extract object by applying the mask to retain all colors
	segmentedMat = cv::Mat::zeros(originalMat.size(), originalMat.type());
	originalMat.copyTo(segmentedMat, binaryMask);

	if (!segmentedMat.empty()) {
		Bitmap^ segmentedBitmap = MatToBitmap(segmentedMat);
		pictureBox2->Image = segmentedBitmap;
	}
}

	   // Assuming BitmapToMat is defined as:
	   inline cv::Mat MVRProject2::MyForm::BitmapToMat(System::Drawing::Bitmap^ bitmap, cv::Mat& mat) {
		   // ... function implementation ...
		   // ... Modify 'mat' here if needed ...
		   return mat; // Return the modified mat if necessary
	   }




private: System::Void trackBar4_Scroll(System::Object^ sender, System::EventArgs^ e) {
	int blueValue = trackBar_Blue->Value;



	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Use the modified image instead of resetting it
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(pictureBox2->Image);

	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(
		rect,
		System::Drawing::Imaging::ImageLockMode::ReadWrite,
		modifiedBitmap->PixelFormat
	);

	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbValues = gcnew array<Byte>(bytes);

	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbValues, 0, bytes);

	// Calculate the difference to adjust smoothly
	int deltaBlue = blueValue - lastBlueValue;

	// Process each pixel in the array
	for (int i = 0; i < rgbValues->Length; i += 4) { // 32bppARGB format
		rgbValues[i] = Math::Min(255, Math::Max(0, rgbValues[i] + deltaBlue)); // Modify only Blue
	}

	System::Runtime::InteropServices::Marshal::Copy(rgbValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);

	pictureBox2->Image = modifiedBitmap;

	// Store the lastBlueValue for incremental adjustments
	lastBlueValue = blueValue;
}

private: System::Void label7_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void label6_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void label8_Click(System::Object^ sender, System::EventArgs^ e) {
}

	   //EXIT BUTTON ASKING IF THEY SURE TO EXIT THE PROGRAM AS IT IS
private: System::Void QtBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	System::Windows::Forms::DialogResult result = MessageBox::Show(
		"Are you sure you want to exit?",
		"EXIT CONFIRMATION",
		MessageBoxButtons::YesNo,
		MessageBoxIcon::Question
	);

	if (result == System::Windows::Forms::DialogResult::Yes) {
		// Check if pictureBox2 contains an image
		if (pictureBox2->Image != nullptr) {
			System::Windows::Forms::DialogResult saveResult = MessageBox::Show(
				"Do you want to save changes before exiting?",
				"SAVE CHANGES",
				MessageBoxButtons::YesNoCancel,
				MessageBoxIcon::Warning
			);

			if (saveResult == System::Windows::Forms::DialogResult::Yes) {
				// Open a Save File Dialog
				SaveFileDialog^ saveFileDialog = gcnew SaveFileDialog();
				saveFileDialog->Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp";
				saveFileDialog->Title = "Save Image";
				saveFileDialog->FileName = "EditedImage"; // Default filename

				// If the user closes the Save Dialog, do NOT exit
				if (saveFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
					pictureBox2->Image->Save(saveFileDialog->FileName);
					Application::Exit(); // Exit after saving
				}
				// If they close the dialog without saving, return to the program
				return;
			}
			else if (saveResult == System::Windows::Forms::DialogResult::No) {
				Application::Exit(); // Exit immediately without saving
			}
			// If "Cancel", do nothing and return to the application
		}
		else {
			Application::Exit(); // Exit if there's no image to save
		}
	}
}

private: System::Void label5_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void trackBar3_Scroll(System::Object^ sender, System::EventArgs^ e) {
	int greenValue = trackBar_Green->Value;

	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Use the already modified image instead of resetting it
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(pictureBox2->Image);

	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(
		rect,
		System::Drawing::Imaging::ImageLockMode::ReadWrite,
		modifiedBitmap->PixelFormat
	);

	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbValues = gcnew array<Byte>(bytes);

	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbValues, 0, bytes);

	// Calculate the difference to adjust smoothly
	int deltaGreen = greenValue - lastGreenValue;

	// Process each pixel in the array
	for (int i = 0; i < rgbValues->Length; i += 4) { // 32bppARGB format
		rgbValues[i + 1] = Math::Min(255, Math::Max(0, rgbValues[i + 1] + deltaGreen)); // Modify only Green
	}

	System::Runtime::InteropServices::Marshal::Copy(rgbValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);

	pictureBox2->Image = modifiedBitmap;

	// Store the lastGreenValue for incremental adjustments
	lastGreenValue = greenValue;
}

private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	originalBitmap = gcnew Bitmap(pictureBox1->Image); // Convert the PictureBox's Image to Bitmap

	for (int y = 0; y < originalBitmap->Height; y++) { // Iterate through each pixel of the image
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y); // Get the color of the pixel at (x, y)

			int r = (int)(originalColor.R * 1.2); // value of rgb in this filter
			int g = (int)(originalColor.G * 1.1);
			int b = (int)(originalColor.B * 0.8);

			r = Math::Min(255, Math::Max(0, r)); //limit the value min of 0 and max of 255
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;
}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image); // Convert the PictureBox's Image to Bitmap

	for (int y = 0; y < originalBitmap->Height; y++) { // Iterate through each pixel of the image to satisfy the image dimension by height and width
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y); // Get pixel color

			// Invert colors (negative effect) fixed value of each color scale minus to the original color of the image
			int r = 255 - originalColor.R;
			int g = 255 - originalColor.G;
			int b = 255 - originalColor.B;

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}

	pictureBox2->Image = originalBitmap; // Display processed image

}

private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y);

			int r = (int)(originalColor.R * 2.5); // Increase Red
			int g = (int)(originalColor.G * 1.5); // Increase Green
			int b = (int)(originalColor.B * 0.5); // Decrease Blue

			r = Math::Min(255, Math::Max(0, r)); // Ensure red stays within 0-255
			g = Math::Min(255, Math::Max(0, g)); // Ensure green stays within 0-255
			b = Math::Min(255, Math::Max(0, b)); // Ensure blue stays within 0-255

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;
}

private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y);

			int r = (int)(originalColor.R * 0.393 + originalColor.G * 0.769 + originalColor.B * 0.189);
			int g = (int)(originalColor.R * 0.349 + originalColor.G * 0.686 + originalColor.B * 0.168);
			int b = (int)(originalColor.R * 0.272 + originalColor.G * 0.534 + originalColor.B * 0.131);

			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;
}

private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {
			Color originalColor = originalBitmap->GetPixel(x, y);

			// Enhance green tones and further reduce blue for a stronger, deeper nature feel
			int r = (int)(originalColor.R * 0.85);  // Further reduce red for a more muted warmth
			int g = (int)(originalColor.G * 1.35); // Significantly boost green for richer foliage
			int b = (int)(originalColor.B * 0.75);  // More strongly reduce blue for deeper warmth

			// Clamp values to prevent overflow
			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			// Set the new pixel color
			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;

}

private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {
			Color originalColor = originalBitmap->GetPixel(x, y);

			// Cyberpunk color grading: Boost blues and purples, reduce warm tones
			int r = (int)(originalColor.R * 0.5);   // Reduce reds
			int g = (int)(originalColor.G * 0.3);   // Reduce greens for a cool, artificial look
			int b = (int)(originalColor.B * 1.5);   // Boost blues for neon/cyber effect

			// Add magenta tint for the cyberpunk aesthetic
			r += (int)(originalColor.B * 0.3); // Add blue influence to red
			g += (int)(originalColor.B * 0.2); // Add a slight blue-green mix

			// Clamp values to prevent overflow
			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			// Set the new pixel color
			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;

}

private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {
			Color originalColor = originalBitmap->GetPixel(x, y);

			// Apply a fade effect by reducing contrast
			int r = (int)(originalColor.R * 0.9 + 25); // Lighten shadows, add a soft tint
			int g = (int)(originalColor.G * 0.9 + 20);
			int b = (int)(originalColor.B * 0.9 + 30); // Slight blue tint for a vintage look

			// Slightly reduce saturation for a muted effect
			int avg = (r + g + b) / 3;
			r = (r + avg) / 2;
			g = (g + avg) / 2;
			b = (b + avg) / 2;

			// Clamp values to prevent overflow
			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			// Set the new pixel color
			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;

}

private: System::Void SvImg_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox2->Image != nullptr) {
		// Confirmation dialog
		System::Windows::Forms::DialogResult result = MessageBox::Show(
			"Are you sure you want to save the executed image?",
			"Confirm Save",
			MessageBoxButtons::YesNo,
			MessageBoxIcon::Question);

		if (result == System::Windows::Forms::DialogResult::Yes) {
			SaveFileDialog^ saveDialog = gcnew SaveFileDialog();
			saveDialog->Filter = "JPEG Image|*.jpg;*.jpeg|PNG Image|*.png";
			saveDialog->Title = "Save Image";

			if (saveDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				System::String^ filePath = saveDialog->FileName;
				System::String^ extension = System::IO::Path::GetExtension(filePath)->ToLower();
				System::Drawing::Imaging::ImageFormat^ format = nullptr;

				// Determine format based on file extension
				if (extension == ".jpg" || extension == ".jpeg") {
					format = System::Drawing::Imaging::ImageFormat::Jpeg;
				}
				else if (extension == ".png") {
					format = System::Drawing::Imaging::ImageFormat::Png;
				}
				else {
					MessageBox::Show("Invalid file format! Please use .jpg or .png", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
					return;
				}

				// Validate file path
				if (System::String::IsNullOrEmpty(filePath)) {
					MessageBox::Show("Invalid file path!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
					return;
				}

				// Validate format
				if (format == nullptr) {
					MessageBox::Show("Invalid file format!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
					return;
				}

				// Clone image as a Bitmap to avoid locked file issue
				System::Drawing::Bitmap^ imageToSave = gcnew System::Drawing::Bitmap(pictureBox2->Image);
				imageToSave->Save(filePath, format);
				delete imageToSave; // Free memory

				MessageBox::Show("Image saved successfully!", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
		}
	}
	else {
		MessageBox::Show("No image to save!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}


private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void trackBar8_Scroll(System::Object^ sender, System::EventArgs^ e) {
	// This function is triggered when trackBar8's value changes (scrolled).

	if (pictureBox1->Image == nullptr) {
		// Check if an image is loaded in pictureBox1.
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		// If no image, show an error message and return.
		return;
	}

	int saturation = trackBar8->Value; // Get the value of trackBar8.
	// The value represents the desired saturation adjustment (0-100 or 0-200).

	// Create a copy of the original bitmap from pictureBox1.
	System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	// Create a new bitmap to store the modified image.
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(originalBitmap);

	// Define a rectangle representing the entire area of the bitmap.
	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	// Lock the bitmap's bits for direct pixel access.
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, modifiedBitmap->PixelFormat);

	// Get a pointer to the start of the bitmap's pixel data.
	IntPtr ptr = bmpData->Scan0;
	// Calculate the total number of bytes in the bitmap's pixel data.
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	// Create a byte array to store the pixel data.
	array<Byte>^ rgbaValues = gcnew array<Byte>(bytes);
	// Copy the pixel data from the bitmap to the byte array.
	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbaValues, 0, bytes);

	// Process each pixel in the image.
	for (int i = 0; i < rgbaValues->Length; i += 4) {
		// Extract RGB values from the byte array.
		float r = rgbaValues[i + 2]; // Red
		float g = rgbaValues[i + 1]; // Green
		float b = rgbaValues[i];     // Blue

		// Convert RGB to HSV.
		float h, s, v;
		RGBtoHSV(r, g, b, h, s, v);

		// Adjust saturation based on trackbar value.
		// Map trackbar value to saturation range [0, 1].
		// Assuming trackBar8 range is 0 to 100, if 0-200, change 100 to 200 below.
		s = (float)saturation / 100.0f;

		// Clamp saturation to the valid range [0, 1].
		s = Math::Min(1.0f, Math::Max(0.0f, s));

		// Convert HSV back to RGB.
		HSVtoRGB(h, s, v, r, g, b);

		// Clamp RGB values to the valid range [0, 255] and update the byte array.
		rgbaValues[i + 2] = (Byte)Math::Min(255, Math::Max(0, (int)r)); // Red
		rgbaValues[i + 1] = (Byte)Math::Min(255, Math::Max(0, (int)g)); // Green
		rgbaValues[i] = (Byte)Math::Min(255, Math::Max(0, (int)b));     // Blue
	}

	// Copy the modified pixel data back to the bitmap.
	System::Runtime::InteropServices::Marshal::Copy(rgbaValues, 0, ptr, bytes);
	// Unlock the bitmap's bits.
	modifiedBitmap->UnlockBits(bmpData);

	// Display the modified image in pictureBox2.
	pictureBox2->Image = modifiedBitmap;
}

	   // RGB to HSV conversion function.
	   void RGBtoHSV(float r, float g, float b, float& h, float& s, float& v) {
		   // Normalize RGB values to the range [0, 1].
		   r /= 255.0f;
		   g /= 255.0f;
		   b /= 255.0f;

		   // Find the maximum and minimum RGB values.
		   float max = Math::Max(Math::Max(r, g), b);
		   float min = Math::Min(Math::Min(r, g), b);
		   // Calculate the difference between the maximum and minimum.
		   float delta = max - min;

		   // Calculate the Value (brightness).
		   v = max;

		   // Calculate the Saturation.
		   if (max == 0.0f) {
			   // If max is 0, saturation is 0.
			   s = 0.0f;
			   // Hue is undefined in this case.
			   h = 0.0f;
			   return;
		   }
		   s = delta / max;

		   // Calculate the Hue.
		   if (delta == 0.0f) {
			   // Hue is undefined if delta is 0.
			   h = 0.0f;
			   return;
		   }

		   if (r == max) {
			   h = (g - b) / delta;
		   }
		   else if (g == max) {
			   h = 2.0f + (b - r) / delta;
		   }
		   else {
			   h = 4.0f + (r - g) / delta;
		   }

		   // Convert hue to degrees.
		   h *= 60.0f;

		   // Ensure hue is in the range [0, 360].
		   if (h < 0.0f) {
			   h += 360.0f;
		   }
	   }

	   // HSV to RGB conversion function.
	   void HSVtoRGB(float h, float s, float v, float& r, float& g, float& b) {
		   // If saturation is 0, the color is grayscale.
		   if (s == 0.0f) {
			   r = g = b = v * 255.0f;
			   return;
		   }

		   // Calculate intermediate values for RGB conversion.
		   h /= 60.0f;
		   int i = (int)h;
		   float f = h - i;
		   float p = v * (1.0f - s);
		   float q = v * (1.0f - s * f);
		   float t = v * (1.0f - s * (1.0f - f));

		   // Determine RGB values based on the hue sector.
		   switch (i) {
		   case 0: r = v; g = t; b = p; break;
		   case 1: r = q; g = v; b = p; break;
		   case 2: r = p; g = v; b = t; break;
		   case 3: r = p; g = q; b = v; break;
		   case 4: r = t; g = p; b = v; break;
		   default: r = v; g = p; b = q; break;
		   }

		   // Scale RGB values back to the range [0, 255].
		   r *= 255.0f;
		   g *= 255.0f;
		   b *= 255.0f;
	   }

private: System::Void trackBar2_Scroll(System::Object^ sender, System::EventArgs^ e) {
	// Get the values from the RGB trackbars
	int redValue = trackBar_Red->Value;
	int greenValue = trackBar_Green->Value;
	int blueValue = trackBar_Blue->Value;

	

	// Check if an image is loaded in pictureBox2
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Use the already modified image instead of resetting it
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(pictureBox2->Image);

	// Define the rectangle covering the entire image
	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);

	// Lock the bitmap for direct pixel access
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(
		rect,
		System::Drawing::Imaging::ImageLockMode::ReadWrite,
		modifiedBitmap->PixelFormat
	);

	// Get a pointer to the raw pixel data
	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbValues = gcnew array<Byte>(bytes);

	// Copy pixel data from the bitmap to the array
	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbValues, 0, bytes);

	// Process each pixel in the array
	for (int i = 0; i < rgbValues->Length; i += 4) { // Assuming 32bppARGB format

		// Adjust only the Red channel
		rgbValues[i + 2] = Math::Min(255, Math::Max(0, rgbValues[i + 2] + redValue - lastRedValue));
	}

	// Copy the modified pixel data back to the bitmap
	System::Runtime::InteropServices::Marshal::Copy(rgbValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);

	// Display the modified image in pictureBox2
	pictureBox2->Image = modifiedBitmap;

	// Update lastRedValue for incremental adjustments
	lastRedValue = redValue;
}

private: System::Void button25_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {
			Color originalColor = originalBitmap->GetPixel(x, y);

			// Increase saturation by boosting each color channel
			int r = (int)(originalColor.R * 1.3); // Boost red
			int g = (int)(originalColor.G * 1.3); // Boost green
			int b = (int)(originalColor.B * 1.3); // Boost blue

			// Apply contrast adjustment
			r = (r - 128) * 1.2 + 128; // Increase contrast
			g = (g - 128) * 1.2 + 128;
			b = (b - 128) * 1.2 + 128;

			// Clamp values to prevent overflow
			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			// Set the new pixel color
			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;

}

private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y);

			int r = (int)(originalColor.R * 0.8);
			int g = (int)(originalColor.G * 1.2);
			int b = (int)(originalColor.B * 0.8);

			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;
}

private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PICTURE BOX IS EMPTY. NO IMAGE TO TERMINATE.",
			"PLEASE SELECT AN IMAGE!", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Ensure that the user has processed the image before clearing
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("You need to process the image before clearing both images!",
			"Process Image First", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Check if pictureBox2 has an image before clearing and ask to save
	System::Windows::Forms::DialogResult saveResult = MessageBox::Show(
		"There is a processed image in the Executed Display.\nWould you like to save it before clearing?",
		"Save Processed Image", MessageBoxButtons::YesNoCancel, MessageBoxIcon::Question);

	if (saveResult == System::Windows::Forms::DialogResult::Yes) {
		SaveFileDialog^ saveFileDialog1 = gcnew SaveFileDialog();
		saveFileDialog1->Filter = "PNG Image|*.png|JPEG Image|*.jpg|Bitmap Image|*.bmp";
		saveFileDialog1->Title = "Save Processed Image";
		saveFileDialog1->FileName = "Processed_Image";

		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			pictureBox2->Image->Save(saveFileDialog1->FileName);
			MessageBox::Show("Image saved successfully!", "Success",
				MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
	}
	else if (saveResult == System::Windows::Forms::DialogResult::Cancel) {
		// If user cancels, do not clear images
		return;
	}

	// Ask for final confirmation before clearing
	System::Windows::Forms::DialogResult result = MessageBox::Show(
		"Are you sure you want to clear both images?", "Confirm Clear",
		MessageBoxButtons::YesNo, MessageBoxIcon::Warning);

	// If the user confirms, clear both images
	if (result == System::Windows::Forms::DialogResult::Yes) {
		pictureBox1->Image = nullptr; // Clear pictureBox1
		pictureBox2->Image = nullptr; // Clear pictureBox2
	}

}

private: System::Void label7_Click_1(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void OptnPnl1_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}

private: System::Void trackBar5_Scroll(System::Object^ sender, System::EventArgs^ e) {
	// Access trackBar5 using its name within the form's context
	int opacity = this->Opacity->Value; // Access the trackbar through 'this
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Create a copy of the original bitmap
	System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox1->Image); // Ensure you're working with the original
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(originalBitmap);

	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, modifiedBitmap->PixelFormat);

	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbaValues = gcnew array<Byte>(bytes);
	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbaValues, 0, bytes);

	// Process each pixel
	for (int i = 0; i < rgbaValues->Length; i += 4) { // Step by 4 since each pixel consists of 4 bytes (RGBA)
		// Extract original RGBA values
		int originalA = rgbaValues[i + 3];

		// Apply opacity adjustment
		int newA = (int)(originalA * opacity / 100.0);
		newA = Math::Min(255, Math::Max(0, newA));

		// Set the new alpha value
		rgbaValues[i + 3] = (Byte)newA;
	}

	System::Runtime::InteropServices::Marshal::Copy(rgbaValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);

	pictureBox2->Image = modifiedBitmap;
}


private: System::Void RstrgbTrckBars_Click(System::Object^ sender, System::EventArgs^ e) {
	// Ensure there is an image in pictureBox2 before resetting
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("NO PROCESSED IMAGE TO RESET!",
			"PROCESS AN IMAGE FIRST!",
			MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Reset the track bars to their default values
	trackBar_Red->Value = 0;
	trackBar_Green->Value = 0;
	trackBar_Blue->Value = 0;

	// Restore the last processed image before RGB adjustments
	pictureBox2->Image = gcnew Bitmap(originalBitmap); // Ensure 'originalProcessedImage' holds the last state before RGB adjustments
}



private: System::Void button11_Click_1(System::Object^ sender, System::EventArgs^ e) {
	// Check if PictureBox2 has an image before allowing the reset
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("NO PROCESSED IMAGE TO RESET!",
			"PROCESS AN IMAGE FIRST!",
			MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Reset trackBar1 to 0
	trackBar1->Value = 0;
	trackBar3->Value = 0;
	trackBar4->Value = 0;
	trackBar3->Value = 0;
	trackBar5->Value = 0;

	// Restore the original image if available
	if (originalBitmap) {
		pictureBox2->Image = gcnew System::Drawing::Bitmap(originalBitmap);
	}
}

private: System::Void RstEnhanceAdjust_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if PictureBox2 has an image before allowing the reset
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("NO PROCESSED IMAGE TO RESET!",
			"PROCESS AN IMAGE FIRST!",
			MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Reset all trackbars to 0
	Opacity->Value = 0;
	trackBar6->Value = 0;
	trackBar7->Value = 0;
	trackBar8->Value = 0;
	trackBar9->Value = 0;
	//trackBar2->Value = 0;


	// Optional: Restore the original image if needed
	if (originalBitmap) {
		pictureBox2->Image = gcnew System::Drawing::Bitmap(originalBitmap);
	}
}

private: System::Void trackBar6_Scroll(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image != nullptr) {
		pictureBox2->Image = pictureBox1->Image;
	}
	else {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	int scrollPosition = trackBar6->Value;

	if (originalBitmap == nullptr) { // Check if originalBitmap has been initialized

		return;
	}
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(originalBitmap);
	// Lock the bits of the modified image
	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, modifiedBitmap->PixelFormat);

	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbValues = gcnew array<Byte>(bytes);
	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbValues, 0, bytes);

	// if ma drag ag bar mu slowly saka ag brightness
	for (int i = 0; i < rgbValues->Length; i++) {

		int newValue = rgbValues[i] + scrollPosition;

		newValue = Math::Min(255, Math::Max(0, newValue));
		rgbValues[i] = (Byte)newValue;// Update the pixel value with the new brightness
	}
	// Copy the modified pixel data back to the image
	System::Runtime::InteropServices::Marshal::Copy(rgbValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);
	pictureBox2->Image = modifiedBitmap;

}
private: System::Void trackBar7_Scroll(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image != nullptr) {
		pictureBox2->Image = pictureBox1->Image;
	}
	else {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	int scrollPosition = trackBar7->Value;

	if (originalBitmap == nullptr) {
		return;
	}
	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(originalBitmap);
	System::Drawing::Rectangle rect(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);
	System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, modifiedBitmap->PixelFormat);

	IntPtr ptr = bmpData->Scan0;
	int bytes = Math::Abs(bmpData->Stride) * modifiedBitmap->Height;
	array<Byte>^ rgbValues = gcnew array<Byte>(bytes);
	System::Runtime::InteropServices::Marshal::Copy(ptr, rgbValues, 0, bytes);

	for (int i = 0; i < rgbValues->Length; i++) {
		int newValue = rgbValues[i] - scrollPosition; // Subtract scrollPosition from the pixel value

		newValue = Math::Min(255, Math::Max(0, newValue));
		rgbValues[i] = (Byte)newValue; // Update the pixel value with the new brightness
	}
	System::Runtime::InteropServices::Marshal::Copy(rgbValues, 0, ptr, bytes);
	modifiedBitmap->UnlockBits(bmpData);

	pictureBox2->Image = modifiedBitmap;

}

private: System::Void trackBar9_Scroll(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	int blurLevel = trackBar9->Value;
	if (blurLevel == 0) { //Optimization: if blurLevel is 0, no change needed
		pictureBox2->Image = originalBitmap; //Use original bitmap if no blur
		return;
	}

	cv::Mat srcMat, blurredMat;
	System::Drawing::Bitmap^ bmp = originalBitmap;
	System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits(System::Drawing::Rectangle(0, 0, bmp->Width, bmp->Height),
		System::Drawing::Imaging::ImageLockMode::ReadOnly,
		bmp->PixelFormat);
	IntPtr ptr = bmpData->Scan0;

	srcMat = cv::Mat(bmp->Height, bmp->Width, CV_8UC4, static_cast<unsigned char*>(ptr.ToPointer()));

	bmp->UnlockBits(bmpData);

	//Optimization: pre-calculate kernel size to avoid redundant calculations
	int kernelSize = blurLevel * 2 + 1;
	cv::GaussianBlur(srcMat, blurredMat, cv::Size(kernelSize, kernelSize), 0, 0);

	System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(blurredMat.cols, blurredMat.rows, bmp->PixelFormat);
	System::Drawing::Imaging::BitmapData^ resultData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, modifiedBitmap->Width, modifiedBitmap->Height),
		System::Drawing::Imaging::ImageLockMode::WriteOnly,
		modifiedBitmap->PixelFormat);
	IntPtr resultPtr = resultData->Scan0;

	//Optimization: directly copy the data instead of creating a new cv::Mat and copying again.
	memcpy(static_cast<unsigned char*>(resultPtr.ToPointer()), blurredMat.data, blurredMat.cols * blurredMat.rows * blurredMat.elemSize());

	modifiedBitmap->UnlockBits(resultData);

	pictureBox2->Image = modifiedBitmap;
}

private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("No image loaded!", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	originalBitmap = gcnew Bitmap(pictureBox1->Image);

	for (int y = 0; y < originalBitmap->Height; y++) {
		for (int x = 0; x < originalBitmap->Width; x++) {

			Color originalColor = originalBitmap->GetPixel(x, y);

			int r = (int)(originalColor.R * 0.7);
			int g = (int)(originalColor.G * 0.9);
			int b = (int)(originalColor.B * 1.3);

			r = Math::Min(255, Math::Max(0, r));
			g = Math::Min(255, Math::Max(0, g));
			b = Math::Min(255, Math::Max(0, b));

			Color newColor = Color::FromArgb(r, g, b);
			originalBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = originalBitmap;
}

private: System::Void AdaptiveBinary_Click(System::Object^ sender, System::EventArgs^ e) {
	// This function converts the original image into BLACK AND WHITE (BINARY IMAGE) using Adaptive Thresholding

	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Create a Bitmap object from the image in pictureBox1
	Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);

	// Get the width and height of the image
	int width = originalBitmap->Width;
	int height = originalBitmap->Height;

	// Lock the bitmap's bits to allow direct pixel manipulation
	System::Drawing::Imaging::BitmapData^ bmpData = originalBitmap->LockBits(
		System::Drawing::Rectangle(0, 0, width, height), // Lock entire image
		System::Drawing::Imaging::ImageLockMode::ReadOnly, // Read-only to avoid modifying original
		System::Drawing::Imaging::PixelFormat::Format24bppRgb
	);

	// Convert Bitmap to OpenCV Mat
	Mat matImage(height, width, CV_8UC3, (void*)bmpData->Scan0, bmpData->Stride);

	// Convert to grayscale
	Mat grayImage;
	cvtColor(matImage, grayImage, COLOR_BGR2GRAY);

	// Unlock the bits of the image **before processing further**
	originalBitmap->UnlockBits(bmpData);

	// Apply adaptive thresholding
	Mat binaryImage;
	adaptiveThreshold(grayImage, binaryImage, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY, 11, 2);

	// Convert OpenCV Mat back to Bitmap safely
	Bitmap^ binBitmap = gcnew Bitmap(width, height, System::Drawing::Imaging::PixelFormat::Format8bppIndexed);

	// Copy pixel data safely
	System::Drawing::Imaging::BitmapData^ binBmpData = binBitmap->LockBits(
		System::Drawing::Rectangle(0, 0, width, height),
		System::Drawing::Imaging::ImageLockMode::WriteOnly,
		System::Drawing::Imaging::PixelFormat::Format8bppIndexed
	);

	memcpy(binBmpData->Scan0.ToPointer(), binaryImage.data, width * height);

	binBitmap->UnlockBits(binBmpData);

	// Display the processed image in pictureBox2
	pictureBox2->Image = binBitmap;
}

private: System::Void label9_Click(System::Object^ sender, System::EventArgs^ e) {
}

	   //FOR OBJECT DETECTION
private: System::Void CheckObjectBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox2->Image != nullptr) {
		System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox2->Image);
		System::Drawing::Bitmap^ bitmap = gcnew System::Drawing::Bitmap(originalBitmap);

		detectShapes(bitmap);

		delete bitmap;
		delete originalBitmap;
	}
	else {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

	   void detectShapes(System::Drawing::Bitmap^ bitmap) {
		   cv::Mat imageMat;
		   imageMat = BitmapToMat(bitmap); // Corrected BitmapToMat function usage

		   cv::Mat grayMat;
		   cv::cvtColor(imageMat, grayMat, cv::COLOR_BGR2GRAY);

		   // Adaptive thresholding for background adjustment
		   double meanGrayValue = cv::mean(grayMat)[0];
		   cv::Mat processedMat;

		   if (meanGrayValue < 128) {
			   cv::threshold(grayMat, processedMat, 1, 255, cv::THRESH_BINARY_INV);
		   }
		   else {
			   processedMat = grayMat.clone();
		   }

		   // Noise reduction
		   cv::Mat blurredMat;
		   cv::GaussianBlur(processedMat, blurredMat, cv::Size(5, 5), 0);

		   // Edge detection
		   cv::Mat edges;
		   cv::Canny(blurredMat, edges, 40, 120);

		   // Find contours
		   std::vector<std::vector<cv::Point>> contours;
		   cv::findContours(edges, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		   int triangleCount = 0, quadrilateralCount = 0, squareCount = 0, rectangleCount = 0, circleCount = 0;

		   for (size_t i = 0; i < contours.size(); ++i) {
			   std::vector<cv::Point> approx;
			   cv::approxPolyDP(contours[i], approx, cv::arcLength(contours[i], true) * 0.02, true);

			   double contourArea = cv::contourArea(contours[i]);
			   double contourPerimeter = cv::arcLength(contours[i], true);

			   if (contourArea < 150) continue; // Ignore small noise

			   if (approx.size() == 3) {
				   if (cv::isContourConvex(approx)) {
					   triangleCount++;
					   drawShapeLabel(imageMat, approx, "Triangle");
				   }
				   else {
					   quadrilateralCount++;
					   drawShapeLabel(imageMat, approx, "Quadrilateral");
				   }
			   }
			   else if (approx.size() == 4) {
				   quadrilateralCount++; // Always count as quadrilateral

				   cv::Rect rect = cv::boundingRect(approx);
				   double aspectRatio = static_cast<double>(rect.width) / rect.height;

				   if (cv::isContourConvex(approx)) {
					   // Check if the shape is a square
					   double areaRatio = contourArea / (rect.width * rect.height);
					   if (aspectRatio >= 0.85 && aspectRatio <= 1.15 && areaRatio >= 0.75) {
						   squareCount++;
						   drawShapeLabel(imageMat, approx, "Square");
					   }
					   // Otherwise, check if it is a rectangle
					   else if ((aspectRatio > 1.2 && aspectRatio <= 2.5) || (aspectRatio < 0.8 && aspectRatio >= 0.4)) {
						   rectangleCount++;
						   drawShapeLabel(imageMat, approx, "Rectangle");
					   }
					   else {
						   drawShapeLabel(imageMat, approx, "Quadrilateral");
					   }
				   }
				   else {
					   drawShapeLabel(imageMat, approx, "Quadrilateral");
				   }
			   }
			   else {
				   // Circularity check for circles
				   double circularity = (4 * CV_PI * contourArea) / (contourPerimeter * contourPerimeter);
				   if (circularity >= 0.8 && approx.size() >= 8) {
					   circleCount++;
					   drawShapeLabel(imageMat, approx, "Circle");
				   }
				   else if (approx.size() >= 4) {
					   quadrilateralCount++;
					   drawShapeLabel(imageMat, approx, "Quadrilateral");
				   }
			   }
		   }

		   // Update UI labels
		   label12->Text = "TRIANGLES: " + triangleCount;
		   label13->Text = "QUADRILATERALS: " + quadrilateralCount;
		   label14->Text = "SQUARES: " + squareCount;
		   label15->Text = "RECTANGLES: " + rectangleCount;
		   label16->Text = "CIRCLES: " + circleCount;
		   label17->Text = "SHAPE DETECTION RESULTS";

		   // Update pictureBox2 with the imageMat with labels
		   pictureBox2->Image = MatToBitmap(imageMat);

	   }

	   // Function to draw shape labels
	   void drawShapeLabel(cv::Mat& imageMat, const std::vector<cv::Point>& contour, const std::string& shapeName) {
		   cv::Moments M = cv::moments(contour);
		   if (M.m00 > 30) {
			   int cx = static_cast<int>(M.m10 / M.m00);
			   int cy = static_cast<int>(M.m01 / M.m00);

			   cv::Scalar textColor = cv::Scalar(0, 0, 0);
			   int baseline = 0;
			   cv::Size textSize = cv::getTextSize(shapeName, cv::FONT_HERSHEY_SIMPLEX, 1.0, 2, &baseline);
			   
			   cv::Rect r = cv::boundingRect(contour);
			   int textX = r.x + (r.width - textSize.width) / 2;
			   int textY = r.y + textSize.height;    // just below the top edge

			   cv::putText(imageMat, shapeName, cv::Point(textX, textY), cv::FONT_HERSHEY_SIMPLEX, 1.0, textColor, 2);
		   }
	   }

	   // This function is triggered when the "CheckColorObjectBtn" button is clicked
private: System::Void CheckColorObjectBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox2
	if (pictureBox2->Image != nullptr) {
		// Convert the image to a Bitmap format
		System::Drawing::Bitmap^ bitmap = gcnew System::Drawing::Bitmap(pictureBox2->Image);
		// Call the detectColors function to process the image
		detectColors(bitmap);
	}
	else {
		// Display an error message if no image is present
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

	   // Function to detect colors in the given bitmap image
	   void detectColors(System::Drawing::Bitmap^ bitmap) {
		   cv::Mat imageMat;
		   // Convert Bitmap to OpenCV Mat
		   imageMat = BitmapToMat(bitmap);

		   // Convert 4-channel image (BGRA) to 3-channel (BGR) if needed
		   if (imageMat.channels() == 4) {
			   cv::cvtColor(imageMat, imageMat, cv::COLOR_BGRA2BGR);
		   }

		   cv::Mat hsvImage;
		   // Convert the image from BGR to HSV color space
		   cv::cvtColor(imageMat, hsvImage, cv::COLOR_BGR2HSV);

		   int redCount = drawColorLabels(imageMat, hsvImage, "R E D", cv::Scalar(0, 100, 100), cv::Scalar(10, 255, 255));
		   redCount += drawColorLabels(imageMat, hsvImage, "R E D", cv::Scalar(160, 100, 100), cv::Scalar(180, 255, 255));

		   int greenCount = drawColorLabels(imageMat, hsvImage, "G R E E N", cv::Scalar(35, 100, 100), cv::Scalar(85, 255, 255));
		   int blueCount = drawColorLabels(imageMat, hsvImage, "B L U E", cv::Scalar(100, 100, 100), cv::Scalar(130, 255, 255));
		   int yellowCount = drawColorLabels(imageMat, hsvImage, "Y E L L O W", cv::Scalar(25, 100, 100), cv::Scalar(34, 255, 255));
		   int orangeCount = drawColorLabels(imageMat, hsvImage, "O R A N G E", cv::Scalar(10, 100, 100), cv::Scalar(20, 255, 255));
		   //this is try only
		   int violetCount = drawColorLabels(imageMat, hsvImage, "V I O L E T", cv::Scalar(130, 100, 50), cv::Scalar(150, 255, 255));
		   // Convert the processed image back to Bitmap format
		   System::Drawing::Bitmap^ resultBitmap = MatToBitmap(imageMat);
		   // Display the processed image in pictureBox2
		   pictureBox2->Image = resultBitmap;

		   // Update labels with detection results
		   label17->Text = "COLOR DETECTION RESULTS";
		   label12->Text = "RED: " + redCount.ToString();
		   label13->Text = "GREEN: " + greenCount.ToString();
		   label14->Text = "BLUE: " + blueCount.ToString();
		   label15->Text = "YELLOW: " + yellowCount.ToString();
		   label16->Text = "ORANGE: " + orangeCount.ToString();
	   }

	   // Function to detect a specific color in the image and label it
	   int drawColorLabels(cv::Mat& imageMat, const cv::Mat& hsvImage, std::string colorName,
		   cv::Scalar lowerBound, cv::Scalar upperBound) {

		   cv::Mat mask;
		   // Threshold the image to detect specific color regions
		   cv::inRange(hsvImage, lowerBound, upperBound, mask);

		   // Define a morphological kernel for noise reduction
		   cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5));
		   // Apply closing operation to fill small gaps
		   cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
		   // Apply opening operation to remove noise
		   cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);

		   std::vector<std::vector<cv::Point>> contours;
		   // Find contours of the detected color regions
		   cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		   // Define a minimum area threshold to filter small noise detections
		   double minArea = imageMat.rows * imageMat.cols * 0.0002;
		   filterContours(contours, minArea);

		   // Iterate through the detected contours
		   for (auto& contour : contours) {
			   std::vector<cv::Point> approxCurve;
			   // Approximate contour shape
			   cv::approxPolyDP(contour, approxCurve, 0.01 * cv::arcLength(contour, true), true);
			   contour = approxCurve;

			   // Calculate the center of the detected object
			   cv::Moments M = cv::moments(contour);
			   if (M.m00 > 30) {
				   int cx = static_cast<int>(M.m10 / M.m00);
				   int cy = static_cast<int>(M.m01 / M.m00);

				   // Set text properties for labeling
				   cv::Scalar textColor = cv::Scalar(0, 0, 0);
				   int baseline = 0;
				   cv::Size textSize = cv::getTextSize(colorName, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, &baseline);
				   int textX = cx - textSize.width / 2;
				   int textY = cy + textSize.height / 2;

				   // Draw the color name at the center of the detected object
				   cv::putText(imageMat, colorName, cv::Point(textX, textY), cv::FONT_HERSHEY_SIMPLEX, 0.5, textColor, 2);
			   }
		   }
		   return static_cast<int>(contours.size());
	   }

	   // Function to filter contours based on area threshold
	   void filterContours(std::vector<std::vector<cv::Point>>& contours, double minArea) {
		   std::vector<std::vector<cv::Point>> filteredContours;
		   for (const auto& contour : contours) {
			   if (cv::contourArea(contour) >= minArea) {
				   filteredContours.push_back(contour);
			   }
		   }
		   contours = filteredContours;
	   }

	   // Function to convert Bitmap to OpenCV Mat
	   cv::Mat BitmapToMat(System::Drawing::Bitmap^ bitmap) {
		   System::Drawing::Rectangle rect(0, 0, bitmap->Width, bitmap->Height);
		   System::Drawing::Imaging::BitmapData^ bmpData = bitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bitmap->PixelFormat);
		   void* ptr = bmpData->Scan0.ToPointer();
		   int bytes = bmpData->Stride * bitmap->Height;
		   cv::Mat mat(bitmap->Height, bitmap->Width, CV_8UC4, ptr, bmpData->Stride);
		   bitmap->UnlockBits(bmpData);
		   cv::Mat matBGR;
		   cv::cvtColor(mat, matBGR, cv::COLOR_BGRA2BGR);
		   return matBGR;
	   }

	   // Function to convert OpenCV Mat to Bitmap
	   System::Drawing::Bitmap^ MatToBitmap(cv::Mat& mat) {
		   System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(mat.cols, mat.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		   System::Drawing::Rectangle rect(0, 0, bmp->Width, bmp->Height);
		   System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits(rect, System::Drawing::Imaging::ImageLockMode::WriteOnly, bmp->PixelFormat);
		   unsigned char* ptr = (unsigned char*)bmpData->Scan0.ToPointer();
		   for (int y = 0; y < mat.rows; y++) {
			   unsigned char* row = mat.ptr<unsigned char>(y);
			   for (int x = 0; x < mat.cols; x++) {
				   ptr[(y * bmpData->Stride) + (x * 3)] = row[x * 3];
				   ptr[(y * bmpData->Stride) + (x * 3) + 1] = row[x * 3 + 1];
				   ptr[(y * bmpData->Stride) + (x * 3) + 2] = row[x * 3 + 2];
			   }
		   }
		   bmp->UnlockBits(bmpData);
		   return bmp;
	   }

private: System::Void label10_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label13_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label17_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void label20_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label18_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void AreaImgBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Create a copy of the loaded image to avoid modifying the original
		System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox1->Image);
		System::Drawing::Bitmap^ bitmap = gcnew System::Drawing::Bitmap(originalBitmap); // Create a new bitmap from the original

		// Get image properties
		int width = bitmap->Width;
		int height = bitmap->Height;

		//Calculate the area directly
		double totalArea = width * height;

		// Display the result
		label36->Text = "Area of the Image:";
		label37->Text = "" + totalArea.ToString() + " pixels";
		label41->Text = "* * * * * *";

		delete originalBitmap; // Clean up the original bitmap copy
		delete bitmap; // Clean up the working bitmap copy
	}
	else {
		// Show an error message if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void button11_Click_2(System::Object^ sender, System::EventArgs^ e) {

	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {

		// Convert the image from pictureBox1 to a Bitmap object
		System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox1->Image);
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(originalBitmap);

		// Create an OpenCV Mat object to store the image
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3); // 8-bit unsigned 3-channel (BGR)

		// Loop through each pixel and convert the Bitmap image to OpenCV Mat
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				System::Drawing::Color clr = bmp->GetPixel(x, y);  // Get pixel color
				cv::Vec3b pixel(clr.B, clr.G, clr.R);  // Convert to OpenCV format (BGR)
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Convert BGR image to HSV color space (better for color segmentation)
		cv::Mat hsvImage;
		cv::cvtColor(image, hsvImage, cv::COLOR_BGR2HSV);

		// Define HSV color ranges for different colors
		cv::Scalar lower_red1(0, 120, 70), upper_red1(10, 255, 255);
		cv::Scalar lower_red2(170, 120, 70), upper_red2(180, 255, 255); // Red is split in HSV
		cv::Scalar lower_green(35, 100, 70), upper_green(85, 255, 255);
		cv::Scalar lower_blue(100, 150, 70), upper_blue(140, 255, 255);
		cv::Scalar lower_yellow(20, 100, 100), upper_yellow(30, 255, 255);
		cv::Scalar lower_orange(10, 150, 150), upper_orange(25, 255, 255);

		// Create masks for each color using inRange function
		cv::Mat maskRed1, maskRed2, maskRed, maskGreen, maskBlue, maskYellow, maskOrange, colorMask;
		cv::inRange(hsvImage, lower_red1, upper_red1, maskRed1);
		cv::inRange(hsvImage, lower_red2, upper_red2, maskRed2);
		cv::inRange(hsvImage, lower_green, upper_green, maskGreen);
		cv::inRange(hsvImage, lower_blue, upper_blue, maskBlue);
		cv::inRange(hsvImage, lower_yellow, upper_yellow, maskYellow);
		cv::inRange(hsvImage, lower_orange, upper_orange, maskOrange);

		// Merge the red masks (since red is in two different HSV ranges)
		cv::bitwise_or(maskRed1, maskRed2, maskRed);

		// Combine all color masks into a single mask
		cv::bitwise_or(maskRed, maskGreen, colorMask);
		cv::bitwise_or(colorMask, maskBlue, colorMask);
		cv::bitwise_or(colorMask, maskYellow, colorMask);
		cv::bitwise_or(colorMask, maskOrange, colorMask);

		// Find contours in the color mask
		std::vector<std::vector<cv::Point>> contours;
		std::vector<cv::Vec4i> hierarchy;
		cv::findContours(colorMask, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		// Clone the original image for drawing
		cv::Mat boxedImage = image.clone();
		System::String^ areaInfo;  // Store the object information for the message box

		// Loop through detected contours
		for (size_t i = 0; i < contours.size(); i++) {
			double area = cv::contourArea(contours[i]);  // Calculate the contour area

			// Ignore small contours (noise filtering)
			if (area < 100) continue;

			// Get the bounding box around the contour
			cv::Rect boundingBox = cv::boundingRect(contours[i]);

			// Determine the color of the detected object
			std::string detectedColor = "Unknown";
			if (cv::countNonZero(maskRed(boundingBox)) > 0) detectedColor = "Red";
			else if (cv::countNonZero(maskGreen(boundingBox)) > 0) detectedColor = "Green";
			else if (cv::countNonZero(maskBlue(boundingBox)) > 0) detectedColor = "Blue";
			else if (cv::countNonZero(maskYellow(boundingBox)) > 0) detectedColor = "Yellow";
			else if (cv::countNonZero(maskOrange(boundingBox)) > 0) detectedColor = "Orange";

			// Append the object details to the message box string
			areaInfo += "Object " + i.ToString() + ": " + gcnew System::String(detectedColor.c_str()) +
				" - " + ((int)area).ToString() + " px\n";

			// Draw the detected contour with red color
			cv::drawContours(boxedImage, contours, i, cv::Scalar(0, 0, 255), 2);

			// Draw a bounding rectangle around the object with purple color
			cv::rectangle(boxedImage, boundingBox, cv::Scalar(130, 0, 75), 5);

			// Draw text displaying the area of the object
			cv::putText(boxedImage, "Area: " + std::to_string(static_cast<int>(area)) + " px",
				cv::Point(boundingBox.x, boundingBox.y - 10),
				cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 0), 2);
		}

		// Convert OpenCV Mat (processed image) back to a Bitmap to display in pictureBox2
		System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(boxedImage.cols, boxedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, boxedImage.cols, boxedImage.rows),
			System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);

		// Copy OpenCV image data to Bitmap
		memcpy(bmpData->Scan0.ToPointer(), boxedImage.data, boxedImage.cols * boxedImage.rows * 3);
		modifiedBitmap->UnlockBits(bmpData);

		// Set the processed image to pictureBox2
		pictureBox2->Image = modifiedBitmap;

		// Show message box with object details
		MessageBox::Show(areaInfo, "OBJECT DETECTION", MessageBoxButtons::OK, MessageBoxIcon::Information);

		// Clean up memory (delete bitmaps to prevent memory leaks)
		delete originalBitmap;
		delete bmp;
		delete modifiedBitmap;
	}
	else {
		// Show error if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void label24_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label31_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label30_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label32_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label33_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void CntrImgBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Convert the loaded image into a Bitmap object
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);

		// Convert the Bitmap to a cv::Mat
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

		// Iterate through each pixel of the bitmap and copy it to the cv::Mat
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				System::Drawing::Color clr = bmp->GetPixel(x, y);
				cv::Vec3b pixel(clr.B, clr.G, clr.R);
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Convert the image to grayscale
		cv::Mat grayImage;
		cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);

		// Threshold the image to create a binary image, adaptive thresholding
		cv::Mat binaryImage;
		cv::adaptiveThreshold(grayImage, binaryImage, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 11, 2);

		// Calculate the moments of the binary image
		cv::Moments moments = cv::moments(binaryImage, true);

		// Calculate the centroid
		double cx = moments.m10 / moments.m00;
		double cy = moments.m01 / moments.m00;

		std::cout << "Centroid (x, y): (" << cx << ", " << cy << ")" << std::endl;

		// Draw the centroid on the original image
		cv::circle(image, cv::Point(cx, cy), 15, cv::Scalar(130, 0, 75), 5); // Blue color for centroid

		// Convert the modified OpenCV image to a Bitmap efficiently
		System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(image.cols, image.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, image.cols, image.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		memcpy(bmpData->Scan0.ToPointer(), image.data, image.cols * image.rows * 3);
		modifiedBitmap->UnlockBits(bmpData);

		// Display the modified image in pictureBox2
		pictureBox2->Image = modifiedBitmap;
	}
	else {
		// Show an error message if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void CntrObjctBtn_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Convert the loaded image into a Bitmap object
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);

		// Convert the Bitmap to a cv::Mat (OpenCV matrix)
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3); // 8-bit unsigned 3-channel (BGR)

		// Iterate through each pixel of the bitmap and copy it to the cv::Mat
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				// Get the color of the pixel at (x, y)
				System::Drawing::Color clr = bmp->GetPixel(x, y);
				// Create an OpenCV Vec3b object (BGR color)
				cv::Vec3b pixel(clr.B, clr.G, clr.R);
				// Assign the pixel to the corresponding location in the cv::Mat
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Convert the image to HSV color space
		cv::Mat hsvImage;
		cv::cvtColor(image, hsvImage, cv::COLOR_BGR2HSV);

		// Create a mask for detecting all objects by segmenting colors
		cv::Mat mask;
		// Segment all colors within the defined HSV range, effectively creating a mask of all detected objects
		cv::inRange(hsvImage, cv::Scalar(0, 30, 50), cv::Scalar(179, 255, 255), mask);

		// Apply morphological operations to remove noise and improve object detection
		cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)); // Create a 3x3 rectangular kernel
		cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel, cv::Point(-1, -1), 2); // Apply opening (erosion then dilation) twice
		cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel, cv::Point(-1, -1), 2); // Apply closing (dilation then erosion) twice

		// Detect edges to improve contour detection
		cv::Mat edges;
		cv::Canny(mask, edges, 50, 150); // Apply Canny edge detection

		// Find contours in the binary mask
		std::vector<std::vector<cv::Point>> contours;
		std::vector<cv::Vec4i> hierarchy;
		cv::findContours(edges, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE); // Find external contours, simple approximation

		// Draw contours in red
		cv::drawContours(image, contours, -1, cv::Scalar(0, 0, 255), 5); // Draw all contours (-1) in red with thickness 5

		// Iterate through each contour and calculate its centroid
		for (const auto& contour : contours) {
			// Calculate moments of the contour
			cv::Moments moments = cv::moments(contour);

			// Ensure moments are valid (avoid division by zero)
			if (moments.m00 > 0) {
				// Calculate centroid of the contour
				double cx = moments.m10 / moments.m00;
				double cy = moments.m01 / moments.m00;

				// Draw centroid on original image
				cv::circle(image, cv::Point(cx, cy), 5, cv::Scalar(130, 0, 75), 5); // Draw a purple circle (centroid) with radius 5 and thickness 5
			}
		}

		// Convert the modified OpenCV image to a Bitmap efficiently
		System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(image.cols, image.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, image.cols, image.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		memcpy(bmpData->Scan0.ToPointer(), image.data, image.cols * image.rows * 3); // Copy pixel data
		modifiedBitmap->UnlockBits(bmpData);

		// Display the modified image in pictureBox2
		pictureBox2->Image = modifiedBitmap;
	}
	else {
		// Show an error message if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Convert the loaded image into a Bitmap object
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);

		// Convert the Bitmap to a cv::Mat
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

		// Iterate through each pixel of the bitmap and copy it to the cv::Mat
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				System::Drawing::Color clr = bmp->GetPixel(x, y);
				cv::Vec3b pixel(clr.B, clr.G, clr.R);
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Draw a bounding box around the entire image
		cv::Mat boxedImage = image.clone();
		cv::rectangle(boxedImage, cv::Point(0, 0), cv::Point(image.cols - 1, image.rows - 1), cv::Scalar(0, 0, 255), 7); // color, thickness 

		// Convert the modified OpenCV image to a Bitmap efficiently
		System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(boxedImage.cols, boxedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, boxedImage.cols, boxedImage.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
		memcpy(bmpData->Scan0.ToPointer(), boxedImage.data, boxedImage.cols * boxedImage.rows * 3);
		modifiedBitmap->UnlockBits(bmpData);

		// Display the result in pictureBox2
		pictureBox2->Image = modifiedBitmap;
	}
	else {
		// Show an error message if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}
private: System::Void button11_Click_3(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Create a Bitmap object from the image in pictureBox1
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);

		// Create an OpenCV Mat object with the same dimensions as the Bitmap
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

		// Loop through each pixel of the Bitmap
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				// Get the color of the pixel at (x, y)
				System::Drawing::Color clr = bmp->GetPixel(x, y);

				// Create an OpenCV Vec3b object (BGR color) from the color
				cv::Vec3b pixel(clr.B, clr.G, clr.R);

				// Assign the pixel to the corresponding location in the OpenCV Mat
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Convert the BGR image to HSV color space
		cv::Mat hsvImage;
		cv::cvtColor(image, hsvImage, cv::COLOR_BGR2HSV);

		// Define lower and upper bounds for red, green, blue, orange, and yellow colors in HSV
		cv::Scalar lowerRed1(0, 100, 100);
		cv::Scalar upperRed1(10, 255, 255);
		cv::Scalar lowerRed2(160, 100, 100);
		cv::Scalar upperRed2(180, 255, 255); // Red is split in HSV due to its circular nature
		cv::Scalar lowerGreen(40, 100, 100);
		cv::Scalar upperGreen(80, 255, 255);
		cv::Scalar lowerBlue(100, 100, 100);
		cv::Scalar upperBlue(140, 255, 255);
		cv::Scalar lowerOrange(10, 100, 100);
		cv::Scalar upperOrange(25, 255, 255);
		cv::Scalar lowerYellow(25, 100, 100);
		cv::Scalar upperYellow(40, 255, 255);

		// Create binary masks for each color using inRange function
		cv::Mat redMask1, redMask2, greenMask, blueMask, orangeMask, yellowMask;
		cv::inRange(hsvImage, lowerRed1, upperRed1, redMask1);
		cv::inRange(hsvImage, lowerRed2, upperRed2, redMask2);
		cv::inRange(hsvImage, lowerGreen, upperGreen, greenMask);
		cv::inRange(hsvImage, lowerBlue, upperBlue, blueMask);
		cv::inRange(hsvImage, lowerOrange, upperOrange, orangeMask);
		cv::inRange(hsvImage, lowerYellow, upperYellow, yellowMask);

		// Combine the two red masks using bitwise OR
		cv::Mat redMask;
		cv::bitwise_or(redMask1, redMask2, redMask);

		// Combine all color masks using bitwise OR
		cv::Mat combinedMask;
		cv::bitwise_or(redMask, greenMask, combinedMask);
		cv::bitwise_or(combinedMask, blueMask, combinedMask);
		cv::bitwise_or(combinedMask, orangeMask, combinedMask);
		cv::bitwise_or(combinedMask, yellowMask, combinedMask);

		// Create a structuring element for morphological operations
		cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5));

		// Apply morphological closing to fill small holes in the mask
		cv::morphologyEx(combinedMask, combinedMask, cv::MORPH_CLOSE, kernel);

		// Apply morphological opening to remove small noise regions
		cv::morphologyEx(combinedMask, combinedMask, cv::MORPH_OPEN, kernel);

		// Find contours in the cleaned-up mask
		std::vector<std::vector<cv::Point>> contours;
		cv::findContours(combinedMask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		// Create a copy of the original image for drawing bounding boxes
		cv::Mat boxedImage = image.clone();

		// Loop through each contour
		for (size_t i = 0; i < contours.size(); i++) {
			// Get the bounding rectangle for the contour
			cv::Rect boundingBox = cv::boundingRect(contours[i]);

			// Check if the bounding box area is greater than 100 pixels to filter small noise
			if (boundingBox.area() > 100) {
				// Draw a rectangle around the contour on the boxedImage
				cv::rectangle(boxedImage, boundingBox, cv::Scalar(130, 0, 75), 5); // Draw a purple bounding box with thickness 5
			}
		}

		// Create a Bitmap object from the modified OpenCV Mat
		System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(boxedImage.cols, boxedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);

		// Lock the bits of the Bitmap for direct memory access
		System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, boxedImage.cols, boxedImage.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);

		// Copy the pixel data from the OpenCV Mat to the Bitmap
		memcpy(bmpData->Scan0.ToPointer(), boxedImage.data, boxedImage.cols * boxedImage.rows * 3);

		// Unlock the bits of the Bitmap
		modifiedBitmap->UnlockBits(bmpData);

		// Display the modified image in pictureBox2
		pictureBox2->Image = modifiedBitmap;
	}
	// If no image is loaded in pictureBox1, show an error message
	else {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox2
	if (pictureBox2->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Convert the PictureBox image to a Bitmap
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox2->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	// Iterate through each pixel of the bitmap and copy it to the cv::Mat
	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}

	// Convert the image to grayscale
	cv::Mat grayImage;
	try {
		cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);
	}
	catch (const cv::Exception& e) {
		MessageBox::Show("Error during grayscale conversion: " + gcnew System::String(e.what()), "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Get the total X and Y dimensions of the image
	int imageWidth = grayImage.cols;
	int imageHeight = grayImage.rows;

	// Display the X and Y dimensions in a MessageBox
	label36->Text = "PHOTO COORDINATES";
	label37->Text = "X = " + imageWidth.ToString() + "px";
	label41->Text = "Y = " + imageHeight.ToString() + "px";
}	   

private: System::Void label14_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label16_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image != nullptr) {
		// Convert the loaded image into a Bitmap object
		System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);

		// Convert the Bitmap to a cv::Mat
		cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

		// Iterate through each pixel of the bitmap and copy it to the cv::Mat
		for (int y = 0; y < bmp->Height; ++y) {
			for (int x = 0; x < bmp->Width; ++x) {
				System::Drawing::Color clr = bmp->GetPixel(x, y);
				cv::Vec3b pixel(clr.B, clr.G, clr.R);
				image.at<cv::Vec3b>(y, x) = pixel;
			}
		}

		// Convert the image to grayscale
		cv::Mat grayImage;
		cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);

		// Threshold the image to create a binary image using Otsu's method
		cv::Mat binaryImage;
		cv::threshold(grayImage, binaryImage, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);

		// Check if the background is white
		bool isWhiteBackground = cv::countNonZero(binaryImage) > (binaryImage.rows * binaryImage.cols) / 2;

		// If the background is white, invert the binary image
		if (isWhiteBackground) {
			cv::bitwise_not(binaryImage, binaryImage);
		}

		// Find contours in the binary image
		std::vector<std::vector<cv::Point>> contours;
		cv::findContours(binaryImage, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		// Build the result string
		System::String^ resultString;

		for (size_t i = 0; i < contours.size(); i++) {
			// Get the bounding box for the contour
			cv::Rect boundingBox = cv::boundingRect(contours[i]);

			// Calculate the centroid (center) of the bounding box
			int centerX = boundingBox.x + boundingBox.width / 2;
			int centerY = boundingBox.y + boundingBox.height / 2;

			// Append the coordinates to the result string
			resultString += "Object " + (i + 1).ToString() + ": X = " + centerX.ToString() + "px ; Y = " + centerY.ToString() + "px\r\n";
		}

		// Display the result in a message box
		MessageBox::Show(resultString, "XY COORDINATES OF THE OBJECT", MessageBoxButtons::OK, MessageBoxIcon::Information);

	}
	else {
		// Show an error message if no image is loaded
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}
private: System::Void label25_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label27_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void panel12_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
private: System::Void label36_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label37_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label41_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label44_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label43_Click(System::Object^ sender, System::EventArgs^ e) {
}


private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void label43_Click_1(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button15_Click_1(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded
	if (originalBitmap == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	cv::Mat originalMat;
	BitmapToMat(originalBitmap, originalMat); // Convert Bitmap to OpenCV Mat
	if (originalMat.empty()) return;

	cv::Mat hsv, mask, segmentedMat;
	cv::cvtColor(originalMat, hsv, cv::COLOR_BGR2HSV); // Convert the image from BGR to HSV color space

	// Define lower and upper bounds for color detection (detects all colors)
	cv::Scalar lower_bound(0, 30, 30);  // Avoids very dark areas
	cv::Scalar upper_bound(180, 255, 255); // Covers the full color range
	cv::inRange(hsv, lower_bound, upper_bound, mask); // Create a binary mask where object regions are white

	// Ensure object colors are preserved by applying mask
	segmentedMat = cv::Mat::zeros(originalMat.size(), originalMat.type()); // Initialize the output image with black background
	originalMat.copyTo(segmentedMat, mask); // Copy object pixels from originalMat using the mask

	if (!segmentedMat.empty()) {
		Bitmap^ segmentedBitmap = MatToBitmap(segmentedMat); // Convert segmented Mat back to Bitmap
		pictureBox2->Image = segmentedBitmap; // Display the segmented image in PictureBox2
	}
}
private: System::Void label40_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: int whiteThreshold = 255; // Default max threshold
private: int blackThreshold = 0;   // Default min threshold

private: System::Void trackBar3_Scroll_2(System::Object^ sender, System::EventArgs^ e) {
	if (originalBitmap == nullptr) return;

	int scrollPosition = trackBar3->Value;
	blackThreshold = (255 * scrollPosition) / trackBar3->Maximum;

	if (blackThreshold >= whiteThreshold) {
		blackThreshold = whiteThreshold - 1;
	}
	ApplyThresholds();
}

private: System::Void trackBar4_Scroll_1(System::Object^ sender, System::EventArgs^ e) {
	if (originalBitmap == nullptr) return;

	int scrollPosition = trackBar4->Value;
	whiteThreshold = (255 * scrollPosition) / trackBar4->Maximum;

	if (whiteThreshold <= blackThreshold) {
		whiteThreshold = blackThreshold + 1;
	}
	ApplyThresholds();
}

private: System::Void ApplyThresholds() {
	if (originalBitmap == nullptr) return;

	Bitmap^ modifiedBitmap = gcnew Bitmap(originalBitmap);
	System::Drawing::Rectangle rect = System::Drawing::Rectangle(0, 0, modifiedBitmap->Width, modifiedBitmap->Height);

	System::Drawing::Imaging::BitmapData^ bmpData =
		modifiedBitmap->LockBits(rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, modifiedBitmap->PixelFormat);

	int bytesPerPixel = System::Drawing::Image::GetPixelFormatSize(modifiedBitmap->PixelFormat) / 8;
	int stride = bmpData->Stride;
	System::IntPtr scan0 = bmpData->Scan0;
	unsigned char* ptr = (unsigned char*)(void*)scan0;

	for (int y = 0; y < modifiedBitmap->Height; y++) {
		unsigned char* row = ptr + (y * stride);

		for (int x = 0; x < modifiedBitmap->Width; x++) {
			unsigned char b = row[x * bytesPerPixel + 0];
			unsigned char g = row[x * bytesPerPixel + 1];
			unsigned char r = row[x * bytesPerPixel + 2];

			int grayValue = (int)(0.299 * r + 0.587 * g + 0.114 * b);
			unsigned char newColor;

			if (grayValue >= whiteThreshold) {
				newColor = 255; // White
			}
			else if (grayValue <= blackThreshold) {
				newColor = 0; // Black
			}
			else {
				continue; // Skip modifying if within range
			}

			row[x * bytesPerPixel + 0] = newColor;
			row[x * bytesPerPixel + 1] = newColor;
			row[x * bytesPerPixel + 2] = newColor;
		}
	}
	modifiedBitmap->UnlockBits(bmpData);
	pictureBox2->Image = modifiedBitmap;
}


private: System::Void trackBar5_Scroll_1(System::Object^ sender, System::EventArgs^ e) {
	if (originalBitmap == nullptr) {
		return;
	}

	int scrollPosition = trackBar5->Value;
	blackThreshold = (scrollPosition == trackBar5->Maximum) ? 255 : (255 * scrollPosition / trackBar5->Maximum);

	// Apply segmentation directly after updating the threshold
	ApplySegmentation(scrollPosition);
}

private: System::Void ApplySegmentation(int sensitivity) {
	if (pictureBox2->Image == nullptr) return; // Ensure there's an image to process

	// Convert the existing displayed image (not originalBitmap)
	cv::Mat img = BitmapToMat(gcnew Bitmap(pictureBox2->Image));
	cv::Mat hsv, mask, segmented;

	// Convert to HSV color space
	cv::cvtColor(img, hsv, cv::COLOR_BGR2HSV);

	// Dynamically adjust segmentation sensitivity
	int minSaturation = (std::max)(50 - sensitivity, 20);
	int minValue = (std::max)(50 - sensitivity, 20);

	// Define color ranges with adjustable S and V values
	std::vector<std::pair<cv::Scalar, cv::Scalar>> colorRanges = {
		{cv::Scalar(0, minSaturation, minValue), cv::Scalar(10, 255, 255)},
		{cv::Scalar(170, minSaturation, minValue), cv::Scalar(180, 255, 255)},
		{cv::Scalar(11, minSaturation, minValue), cv::Scalar(25, 255, 255)},
		{cv::Scalar(26, minSaturation, minValue), cv::Scalar(35, 255, 255)},
		{cv::Scalar(36, minSaturation, minValue), cv::Scalar(85, 255, 255)},
		{cv::Scalar(86, minSaturation, minValue), cv::Scalar(125, 255, 255)},
		{cv::Scalar(126, minSaturation, minValue), cv::Scalar(140, 255, 255)},
		{cv::Scalar(141, minSaturation, minValue), cv::Scalar(160, 255, 255)}
	};

	// Corresponding colors for segmentation visualization
	std::vector<cv::Scalar> segmentColors = {
		cv::Scalar(0, 0, 255),   // Red
		cv::Scalar(0, 0, 255),   // Red (upper)
		cv::Scalar(0, 165, 255), // Orange
		cv::Scalar(0, 255, 255), // Yellow
		cv::Scalar(0, 255, 0),   // Green
		cv::Scalar(255, 0, 0),   // Blue
		cv::Scalar(75, 0, 130),  // Indigo
		cv::Scalar(238, 130, 238) // Violet
	};

	// Use the existing image as the base instead of white
	segmented = img.clone();

	// Loop through each color range and segment
	for (size_t i = 0; i < colorRanges.size(); ++i) {
		cv::Mat tempMask;
		cv::inRange(hsv, colorRanges[i].first, colorRanges[i].second, tempMask);
		segmented.setTo(segmentColors[i], tempMask);
	}

	// Convert back to Bitmap and display
	pictureBox2->Image = MatToBitmap(segmented);
}




private: System::Void button15_Click_2(System::Object^ sender, System::EventArgs^ e) {
    if (pictureBox1->Image != nullptr) {
        // Convert the loaded image into a Bitmap object
        System::Drawing::Bitmap^ originalBmp = gcnew System::Drawing::Bitmap(pictureBox1->Image); // Store original

        // Convert the Bitmap to a cv::Mat
        cv::Mat image(originalBmp->Height, originalBmp->Width, CV_8UC3);

        // Iterate through each pixel of the bitmap and copy it to the cv::Mat
        for (int y = 0; y < originalBmp->Height; ++y) {
            for (int x = 0; x < originalBmp->Width; ++x) {
                System::Drawing::Color clr = originalBmp->GetPixel(x, y);
                cv::Vec3b pixel(clr.B, clr.G, clr.R);
                image.at<cv::Vec3b>(y, x) = pixel;
            }
        }

        // Increase the rotation angle by 50 degrees
        rotationAngle += 90;

        // Ensure the rotation angle stays within 0-360 degrees
        rotationAngle = (rotationAngle % 360 + 360) % 360; // Handle negative angles

        // Rotate the image
        cv::Mat rotatedImage;
        cv::Point2f center(image.cols / 2.0f, image.rows / 2.0f);
        cv::Mat rotationMatrix = cv::getRotationMatrix2D(center, rotationAngle, 1.0);
        cv::warpAffine(image, rotatedImage, rotationMatrix, cv::Size(image.cols, image.rows));

        // Convert the rotated OpenCV image to a Bitmap efficiently
        System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(rotatedImage.cols, rotatedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
        System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, rotatedImage.cols, rotatedImage.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
        memcpy(bmpData->Scan0.ToPointer(), rotatedImage.data, rotatedImage.cols * rotatedImage.rows * 3);
        modifiedBitmap->UnlockBits(bmpData);

        // Display the rotated image in pictureBox2
        pictureBox2->Image = modifiedBitmap;

        //If rotationAngle is 0, display the original image.
        if (rotationAngle == 0) {
            pictureBox2->Image = originalBmp;
        }

    } else {
        // Show an error message if no image is loaded
        MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
}

private: System::Void button16_Click(System::Object^ sender, System::EventArgs^ e) {
    if (pictureBox1->Image != nullptr) {
        // Convert the loaded image into a Bitmap object
        System::Drawing::Bitmap^ originalBmp = gcnew System::Drawing::Bitmap(pictureBox1->Image); // Store original

        // Convert the Bitmap to a cv::Mat
        cv::Mat image(originalBmp->Height, originalBmp->Width, CV_8UC3);

        // Iterate through each pixel of the bitmap and copy it to the cv::Mat
        for (int y = 0; y < originalBmp->Height; ++y) {
            for (int x = 0; x < originalBmp->Width; ++x) {
                System::Drawing::Color clr = originalBmp->GetPixel(x, y);
                cv::Vec3b pixel(clr.B, clr.G, clr.R);
                image.at<cv::Vec3b>(y, x) = pixel;
            }
        }

        // Decrease the rotation angle by 50 degrees (rotate left)
        rotationAngle -= 90;

        // Ensure the rotation angle stays within 0-360 degrees
        rotationAngle = (rotationAngle % 360 + 360) % 360; // Handle negative angles

        // Rotate the image
        cv::Mat rotatedImage;
        cv::Point2f center(image.cols / 2.0f, image.rows / 2.0f);
        cv::Mat rotationMatrix = cv::getRotationMatrix2D(center, rotationAngle, 1.0);
        cv::warpAffine(image, rotatedImage, rotationMatrix, cv::Size(image.cols, image.rows));

        // Convert the rotated OpenCV image to a Bitmap efficiently
        System::Drawing::Bitmap^ modifiedBitmap = gcnew System::Drawing::Bitmap(rotatedImage.cols, rotatedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
        System::Drawing::Imaging::BitmapData^ bmpData = modifiedBitmap->LockBits(System::Drawing::Rectangle(0, 0, rotatedImage.cols, rotatedImage.rows), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
        memcpy(bmpData->Scan0.ToPointer(), rotatedImage.data, rotatedImage.cols * rotatedImage.rows * 3);
        modifiedBitmap->UnlockBits(bmpData);

        // Display the rotated image in pictureBox2
        pictureBox2->Image = modifiedBitmap;

        //If rotationAngle is 0, display the original image.
        if (rotationAngle == 0) {
            pictureBox2->Image = originalBmp;
        }

    } else {
        // Show an error message if no image is loaded
        MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
}

private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
		// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox2->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}

	cv::Mat mirroredImage;
	cv::flip(image, mirroredImage, 1); // 1 for horizontal flip, 0 for vertical flip

	System::Drawing::Bitmap^ mirroredBitmap = gcnew System::Drawing::Bitmap(mirroredImage.cols, mirroredImage.rows);

	for (int y = 0; y < mirroredBitmap->Height; ++y) {
		for (int x = 0; x < mirroredBitmap->Width; ++x) {
			cv::Vec3b pixel = mirroredImage.at<cv::Vec3b>(y, x);
			mirroredBitmap->SetPixel(x, y, System::Drawing::Color::FromArgb(pixel[2], pixel[1], pixel[0]));
		}
	}
	pictureBox2->Image = mirroredBitmap;
}

private: System::Void button19_Click(System::Object^ sender, System::EventArgs^ e) {
		// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	// Convert the PictureBox image to a cv::Mat
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox2->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);
	// Iterate through each pixel of the bitmap and copy it to the cv::Mat
	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}
	// Mirror the image vertically
	cv::Mat mirroredImage;
	cv::flip(image, mirroredImage, 0); // 0 for vertical flip, 1 for horizontal flip
	// Convert the mirrored OpenCV image to a Bitmap
	System::Drawing::Bitmap^ mirroredBitmap = gcnew System::Drawing::Bitmap(mirroredImage.cols, mirroredImage.rows);
	// Iterate through each pixel of the cv::Mat and copy it to the Bitmap
	for (int y = 0; y < mirroredBitmap->Height; ++y) {
		for (int x = 0; x < mirroredBitmap->Width; ++x) {
			cv::Vec3b pixel = mirroredImage.at<cv::Vec3b>(y, x);
			mirroredBitmap->SetPixel(x, y, System::Drawing::Color::FromArgb(pixel[2], pixel[1], pixel[0]));
		}
	}
	pictureBox2->Image = mirroredBitmap;
}


private: System::Void label44_Click_1(System::Object^ sender, System::EventArgs^ e) {
}

	   // Red, Green, and Blue Channel Vertical Projection Histograms
private: System::Void button20_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	label50->Text = "RGB PROJECTION HISTOGRAMS";

	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	int totalRedPixels = 0;
	int totalGreenPixels = 0;
	int totalBluePixels = 0;

	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;

			if (clr.R > 128) {
				totalRedPixels++;
			}
			if (clr.G > 128) {
				totalGreenPixels++;
			}
			if (clr.B > 128) {
				totalBluePixels++;
			}
		}
	}

	label53->Text = "RED:\n" + totalRedPixels.ToString () + " px";   // Red
	label52->Text = "GREEN:\n" + totalGreenPixels.ToString() + " px"; // Green
	label51->Text = "BLUE:\n" + totalBluePixels.ToString() + " px";  // Blue
	label54->Text = "TOTAL:\n" + (totalRedPixels + totalGreenPixels + totalBluePixels).ToString() + " px"; // Total

	// Extract BGR Channels
	std::vector<cv::Mat> bgr_planes;
	cv::split(image, bgr_planes);
	cv::Mat blueChannel = bgr_planes[0];
	cv::Mat greenChannel = bgr_planes[1];
	cv::Mat redChannel = bgr_planes[2];

	// Threshold Channels
	cv::Mat binaryBlue, binaryGreen, binaryRed;
	cv::threshold(blueChannel, binaryBlue, 128, 255, cv::THRESH_BINARY);
	cv::threshold(greenChannel, binaryGreen, 128, 255, cv::THRESH_BINARY);
	cv::threshold(redChannel, binaryRed, 128, 255, cv::THRESH_BINARY);

	// Create Vertical Projections
	cv::Mat verticalProjectionBlue = cv::Mat::zeros(1, binaryBlue.cols, CV_32SC1);
	cv::Mat verticalProjectionGreen = cv::Mat::zeros(1, binaryGreen.cols, CV_32SC1);
	cv::Mat verticalProjectionRed = cv::Mat::zeros(1, binaryRed.cols, CV_32SC1);

	for (int x = 0; x < binaryBlue.cols; ++x) {
		verticalProjectionBlue.at<int>(0, x) = cv::countNonZero(binaryBlue.col(x));
		verticalProjectionGreen.at<int>(0, x) = cv::countNonZero(binaryGreen.col(x));
		verticalProjectionRed.at<int>(0, x) = cv::countNonZero(binaryRed.col(x));
	}

	// Normalize and Draw Projections
	double minBlue, maxBlue, minGreen, maxGreen, minRed, maxRed;
	cv::minMaxLoc(verticalProjectionBlue, &minBlue, &maxBlue);
	cv::minMaxLoc(verticalProjectionGreen, &minGreen, &maxGreen);
	cv::minMaxLoc(verticalProjectionRed, &minRed, &maxRed);

	cv::Mat verticalProjectionImageBlue(binaryBlue.rows, binaryBlue.cols, CV_8UC3, cv::Scalar(255, 255, 255));
	cv::Mat verticalProjectionImageGreen(binaryGreen.rows, binaryGreen.cols, CV_8UC3, cv::Scalar(255, 255, 255));
	cv::Mat verticalProjectionImageRed(binaryRed.rows, binaryRed.cols, CV_8UC3, cv::Scalar(255, 255, 255));

	for (int x = 0; x < binaryBlue.cols; ++x) {
		int lengthBlue = static_cast<int>((verticalProjectionBlue.at<int>(0, x) / maxBlue) * binaryBlue.rows);
		int lengthGreen = static_cast<int>((verticalProjectionGreen.at<int>(0, x) / maxGreen) * binaryGreen.rows);
		int lengthRed = static_cast<int>((verticalProjectionRed.at<int>(0, x) / maxRed) * binaryRed.rows);

		cv::line(verticalProjectionImageBlue, cv::Point(x, binaryBlue.rows - 1), cv::Point(x, binaryBlue.rows - 1 - lengthBlue), cv::Scalar(255, 0, 0), 1); // Blue
		cv::line(verticalProjectionImageGreen, cv::Point(x, binaryGreen.rows - 1), cv::Point(x, binaryGreen.rows - 1 - lengthGreen), cv::Scalar(0, 255, 0), 1); // Green
		cv::line(verticalProjectionImageRed, cv::Point(x, binaryRed.rows - 1), cv::Point(x, binaryRed.rows - 1 - lengthRed), cv::Scalar(0, 0, 255), 1);     // Red
	}

	// Convert to Bitmaps and display
	System::Drawing::Bitmap^ projectionBitmapBlue = gcnew System::Drawing::Bitmap(verticalProjectionImageBlue.cols, verticalProjectionImageBlue.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	System::Drawing::Bitmap^ projectionBitmapGreen = gcnew System::Drawing::Bitmap(verticalProjectionImageGreen.cols, verticalProjectionImageGreen.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	System::Drawing::Bitmap^ projectionBitmapRed = gcnew System::Drawing::Bitmap(verticalProjectionImageRed.cols, verticalProjectionImageRed.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);

	// Blue Bitmap
	System::Drawing::Imaging::BitmapData^ bmpDataBlue = projectionBitmapBlue->LockBits(System::Drawing::Rectangle(0, 0, projectionBitmapBlue->Width, projectionBitmapBlue->Height), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	uchar* pSrcBlue = verticalProjectionImageBlue.data;
	uchar* pDstBlue = (uchar*)bmpDataBlue->Scan0.ToPointer();
	int strideBlue = bmpDataBlue->Stride;
	for (int y = 0; y < verticalProjectionImageBlue.rows; ++y) {
		memcpy(pDstBlue + y * strideBlue, pSrcBlue + y * verticalProjectionImageBlue.step, verticalProjectionImageBlue.cols * 3);
	}
	projectionBitmapBlue->UnlockBits(bmpDataBlue);

	// Green Bitmap
	System::Drawing::Imaging::BitmapData^ bmpDataGreen = projectionBitmapGreen->LockBits(System::Drawing::Rectangle(0, 0, projectionBitmapGreen->Width, projectionBitmapGreen->Height), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	uchar* pSrcGreen = verticalProjectionImageGreen.data;
	uchar* pDstGreen = (uchar*)bmpDataGreen->Scan0.ToPointer();
	int strideGreen = bmpDataGreen->Stride;
	for (int y = 0; y < verticalProjectionImageGreen.rows; ++y) {
		memcpy(pDstGreen + y * strideGreen, pSrcGreen + y * verticalProjectionImageGreen.step, verticalProjectionImageGreen.cols * 3);
	}
	projectionBitmapGreen->UnlockBits(bmpDataGreen);

	// Red Bitmap
	System::Drawing::Imaging::BitmapData^ bmpDataRed = projectionBitmapRed->LockBits(System::Drawing::Rectangle(0, 0, projectionBitmapRed->Width, projectionBitmapRed->Height), System::Drawing::Imaging::ImageLockMode::WriteOnly, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	uchar* pSrcRed = verticalProjectionImageRed.data;
	uchar* pDstRed = (uchar*)bmpDataRed->Scan0.ToPointer();
	int strideRed = bmpDataRed->Stride;
	for (int y = 0; y < verticalProjectionImageRed.rows; ++y) {
		memcpy(pDstRed + y * strideRed, pSrcRed + y * verticalProjectionImageRed.step, verticalProjectionImageRed.cols * 3);
	}
	projectionBitmapRed->UnlockBits(bmpDataRed);

	pictureBox4->Image = projectionBitmapRed; // Red
	pictureBox3->Image = projectionBitmapGreen; // Green
	pictureBox5->Image = projectionBitmapBlue; // Blue
}

//binary image projection IN VERTICAL
private: System::Void button21_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) { // nullptr means no image is loaded
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}
	// Convert the image to grayscale
	cv::Mat grayImage;
	cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);

	// Threshold the image to create a binary image
	cv::Mat binaryImage;
	cv::threshold(grayImage, binaryImage, 128, 255, cv::THRESH_BINARY);

	// Create vertical projection
	cv::Mat verticalProjection = cv::Mat::zeros(1, binaryImage.cols, CV_32SC1);
	for (int x = 0; x < binaryImage.cols; ++x) {
		verticalProjection.at<int>(0, x) = cv::countNonZero(binaryImage.col(x));
	}

	// Normalize the vertical projection to fit in an image
	double min, max;
	cv::minMaxLoc(verticalProjection, &min, &max);
	cv::Mat verticalProjectionImage(binaryImage.rows, binaryImage.cols, CV_8UC1, cv::Scalar(255));
	for (int x = 0; x < binaryImage.cols; ++x) {
		int length = static_cast<int>((verticalProjection.at<int>(0, x) / max) * binaryImage.rows);
		cv::line(verticalProjectionImage, cv::Point(x, binaryImage.rows - 1), cv::Point(x, binaryImage.rows - 1 - length), cv::Scalar(0), 1);
	}
	// Convert the projection image to a Bitmap
	System::Drawing::Bitmap^ projectionBitmap = gcnew System::Drawing::Bitmap(verticalProjectionImage.cols, verticalProjectionImage.rows, System::Drawing::Imaging::PixelFormat::Format8bppIndexed);
	// Lock the bits of the projection image
	System::Drawing::Imaging::BitmapData^ bmpData = projectionBitmap->LockBits(System::Drawing::Rectangle(0, 0, projectionBitmap->Width, projectionBitmap->Height), System::Drawing::Imaging::ImageLockMode::ReadWrite, System::Drawing::Imaging::PixelFormat::Format8bppIndexed);

	// Copy data from cv::Mat to Bitmap
	uchar* pSrc = verticalProjectionImage.data;
	uchar* pDst = (uchar*)bmpData->Scan0.ToPointer();
	int stride = bmpData->Stride;

	for (int y = 0; y < verticalProjectionImage.rows; ++y) {
		memcpy(pDst + y * stride, pSrc + y * verticalProjectionImage.step, verticalProjectionImage.cols);
	}
	// Unlock the bits
	projectionBitmap->UnlockBits(bmpData);

	// Set grayscale palette for Bitmap
	System::Drawing::Imaging::ColorPalette^ palette = projectionBitmap->Palette;
	for (int i = 0; i < 256; ++i) {
		palette->Entries[i] = System::Drawing::Color::FromArgb(i, i, i);
	}
	projectionBitmap->Palette = palette;

	pictureBox2->Image = projectionBitmap;
}
//Binary Image Projection IN HORIZONTAL
private: System::Void button22_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) { // nullptr means no image is loaded
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}

	cv::Mat grayImage;
	cv::cvtColor(image, grayImage, cv::COLOR_BGR2GRAY);

	// Threshold the image to create a binary image
	cv::Mat binaryImage;
	cv::threshold(grayImage, binaryImage, 128, 255, cv::THRESH_BINARY);

	// Create horizontal projection
	cv::Mat horizontalProjection = cv::Mat::zeros(binaryImage.rows, 1, CV_32SC1);
	for (int y = 0; y < binaryImage.rows; ++y) {
		horizontalProjection.at<int>(y, 0) = cv::countNonZero(binaryImage.row(y));
	}

	// Normalize the horizontal projection to fit in an image
	double min, max;
	cv::minMaxLoc(horizontalProjection, &min, &max);
	cv::Mat horizontalProjectionImage(binaryImage.rows, binaryImage.cols, CV_8UC1, cv::Scalar(255));
	for (int y = 0; y < binaryImage.rows; ++y) {
		int length = static_cast<int>((horizontalProjection.at<int>(y, 0) / max) * binaryImage.cols);
		cv::line(horizontalProjectionImage, cv::Point(0, y), cv::Point(length, y), cv::Scalar(0), 1);
	}

	// Convert the projection image to a Bitmap
	System::Drawing::Bitmap^ projectionBitmap = gcnew System::Drawing::Bitmap(horizontalProjectionImage.cols, horizontalProjectionImage.rows, System::Drawing::Imaging::PixelFormat::Format8bppIndexed);

	// Lock the bits of the projection image
	System::Drawing::Imaging::BitmapData^ bmpData = projectionBitmap->LockBits(System::Drawing::Rectangle(0, 0, projectionBitmap->Width, projectionBitmap->Height), System::Drawing::Imaging::ImageLockMode::ReadWrite, System::Drawing::Imaging::PixelFormat::Format8bppIndexed);

	// Copy data from cv::Mat to Bitmap
	uchar* pSrc = horizontalProjectionImage.data;
	uchar* pDst = (uchar*)bmpData->Scan0.ToPointer();
	int stride = bmpData->Stride;

	for (int y = 0; y < horizontalProjectionImage.rows; ++y) {
		memcpy(pDst + y * stride, pSrc + y * horizontalProjectionImage.step, horizontalProjectionImage.cols);
	}
	// Unlock the bits
	projectionBitmap->UnlockBits(bmpData);
	// Set grayscale palette for Bitmap
	System::Drawing::Imaging::ColorPalette^ palette = projectionBitmap->Palette;
	for (int i = 0; i < 256; ++i) {
		palette->Entries[i] = System::Drawing::Color::FromArgb(i, i, i);
	}
	projectionBitmap->Palette = palette;

	pictureBox2->Image = projectionBitmap;
}

private: System::Void label50_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void trackBar2_Scroll_1(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE LOAD AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Get rotation angle from trackBar2
	double rotationAngle = static_cast<double>(trackBar2->Value);

	// Display rotation direction
	if (rotationAngle > 0)
		label47->Text = rotationAngle.ToString() + "° Right";
	else if (rotationAngle < 0)
		label47->Text = (-rotationAngle).ToString() + "° Left";
	else
		label47->Text = "0°";

	// Convert pictureBox1 image to cv::Mat
	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	cv::Mat image(bmp->Height, bmp->Width, CV_8UC3);

	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			image.at<cv::Vec3b>(y, x) = pixel;
		}
	}

	// Setup rotation
	cv::Point2f center(static_cast<float>(image.cols / 2), static_cast<float>(image.rows / 2));
	cv::Mat rotationMatrix = cv::getRotationMatrix2D(center, -rotationAngle, 1.0); // OpenCV uses clockwise as negative
	cv::Rect bbox = cv::RotatedRect(center, image.size(), rotationAngle).boundingRect();

	rotationMatrix.at<double>(0, 2) += bbox.width / 2.0 - center.x;
	rotationMatrix.at<double>(1, 2) += bbox.height / 2.0 - center.y;

	cv::Mat rotatedImage;
	cv::warpAffine(image, rotatedImage, rotationMatrix, bbox.size());

	// Convert rotated cv::Mat back to Bitmap
	System::Drawing::Bitmap^ rotatedBitmap = gcnew System::Drawing::Bitmap(rotatedImage.cols, rotatedImage.rows);
	for (int y = 0; y < rotatedImage.rows; ++y) {
		for (int x = 0; x < rotatedImage.cols; ++x) {
			cv::Vec3b pixel = rotatedImage.at<cv::Vec3b>(y, x);
			rotatedBitmap->SetPixel(x, y, System::Drawing::Color::FromArgb(pixel[2], pixel[1], pixel[0]));
		}
	}

	// Show rotated image
	pictureBox2->Image = rotatedBitmap;
}


private: System::Void button17_Click(System::Object^ sender, System::EventArgs^ e) {
	trackBar2->Value = 0;
	label47->Text = "0 Degree/s"; // Correctly set the label text

	if (pictureBox1->Image != nullptr) {
		pictureBox2->Image = gcnew System::Drawing::Bitmap(pictureBox1->Image); // Reset pictureBox2 to original image
	}
	else {
		pictureBox2->Image = nullptr; // Clear pictureBox2 if no original image
	}
}

private: System::Void label52_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label53_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label51_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label54_Click(System::Object^ sender, System::EventArgs^ e) {
}

	   //Move when the X and Y coordinates
private: System::Void button23_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Get the translation values from the text boxes
	int translateX, translateY;
	if (!System::Int32::TryParse(textBox1->Text, translateX)) {
		MessageBox::Show("Invalid X coordinate input.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (!System::Int32::TryParse(textBox2->Text, translateY)) {
		MessageBox::Show("Invalid Y coordinate input.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	System::Drawing::Bitmap^ bmp = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	cv::Mat sourceImage(bmp->Height, bmp->Width, CV_8UC3);

	// Convert the System::Drawing::Bitmap to an OpenCV cv::Mat
	for (int y = 0; y < bmp->Height; ++y) {
		for (int x = 0; x < bmp->Width; ++x) {
			System::Drawing::Color clr = bmp->GetPixel(x, y);
			cv::Vec3b pixel(clr.B, clr.G, clr.R);
			sourceImage.at<cv::Vec3b>(y, x) = pixel;
		}
	}

	// Create the translation matrix
	cv::Mat translationMatrix = (cv::Mat_<double>(2, 3) << 1, 0, translateX, 0, 1, translateY);

	// Apply the affine transformation (translation)
	cv::Mat translatedImage;
	cv::warpAffine(sourceImage, translatedImage, translationMatrix, sourceImage.size());

	// Convert the translated OpenCV cv::Mat back to a System::Drawing::Bitmap for pictureBox2
	System::Drawing::Bitmap^ translatedBmp = gcnew System::Drawing::Bitmap(translatedImage.cols, translatedImage.rows, System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	System::Drawing::Imaging::BitmapData^ bmpData = translatedBmp->LockBits(System::Drawing::Rectangle(0, 0, translatedBmp->Width, translatedBmp->Height), System::Drawing::Imaging::ImageLockMode::WriteOnly, translatedBmp->PixelFormat);
	unsigned char* ptr = (unsigned char*)bmpData->Scan0.ToPointer();

	for (int y = 0; y < translatedImage.rows; ++y) {
		for (int x = 0; x < translatedImage.cols; ++x) {
			cv::Vec3b pixel = translatedImage.at<cv::Vec3b>(y, x);
			ptr[y * bmpData->Stride + x * 3 + 0] = pixel[0]; // Blue
			ptr[y * bmpData->Stride + x * 3 + 1] = pixel[1]; // Green
			ptr[y * bmpData->Stride + x * 3 + 2] = pixel[2]; // Red
		}
	}
	translatedBmp->UnlockBits(bmpData);

	// Display the translated image in pictureBox2
	pictureBox2->Image = translatedBmp;
}

private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {

}
private: System::Void textBox2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button24_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	System::Drawing::Bitmap^ currentImage = gcnew System::Drawing::Bitmap(pictureBox1->Image);
	int width = currentImage->Width;
	int height = currentImage->Height;

	// Define the smoothing kernel (3x3 Mean filter)
	array<double, 2>^ kernel = {
		{1.0 / 9, 1.0 / 9, 1.0 / 9},
		{1.0 / 9, 1.0 / 9, 1.0 / 9},
		{1.0 / 9, 1.0 / 9, 1.0 / 9}
	};
	int kernelWidth = kernel->GetLength(1);
	int kernelHeight = kernel->GetLength(0);
	int kernelRadiusX = kernelWidth / 2;
	int kernelRadiusY = kernelHeight / 2;

	int numberOfPasses = 5; // Increased to 5 passes for more smoothing

	for (int pass = 0; pass < numberOfPasses; pass++) {
		System::Drawing::Bitmap^ smoothedImage = gcnew System::Drawing::Bitmap(width, height);

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				double sumR = 0, sumG = 0, sumB = 0;

				for (int ky = -kernelRadiusY; ky <= kernelRadiusY; ky++) {
					for (int kx = -kernelRadiusX; kx <= kernelRadiusX; kx++) {
						int sampleX = x + kx;
						int sampleY = y + ky;

						if (sampleX >= 0 && sampleX < width && sampleY >= 0 && sampleY < height) {
							System::Drawing::Color pixelColor = currentImage->GetPixel(sampleX, sampleY);
							double kernelValue = kernel[ky + kernelRadiusY, kx + kernelRadiusX];

							sumR += pixelColor.R * kernelValue;
							sumG += pixelColor.G * kernelValue;
							sumB += pixelColor.B * kernelValue;
						}
					}
				}

				System::Drawing::Color newColor = System::Drawing::Color::FromArgb(
					System::Math::Min(255, System::Math::Max(0, static_cast<int>(sumR + 0.5))),
					System::Math::Min(255, System::Math::Max(0, static_cast<int>(sumG + 0.5))),
					System::Math::Min(255, System::Math::Max(0, static_cast<int>(sumB + 0.5)))
				);
				smoothedImage->SetPixel(x, y, newColor);
			}
		}
		// Update currentImage for the next pass
		currentImage = smoothedImage;
	}

	// Display the final smoothed image in pictureBox2
	pictureBox2->Image = currentImage;
}

private: System::Void button29_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Clear the text in the specified TextBoxes
	textBox3->Clear();
	textBox4->Clear();
	textBox5->Clear();
	textBox6->Clear();
	textBox7->Clear();
	textBox8->Clear();
	textBox9->Clear();
	textBox10->Clear();
	textBox11->Clear();
}

private: System::Void textBox3_TextChanged(System::Object^ sender, System::EventArgs^ e) {	
}

private: System::Void textBox4_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox5_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox6_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox7_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox8_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox9_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox10_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void textBox11_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button27_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) { // nullptr means no image is loaded
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	// Convert the PictureBox's Image to Bitmap
	Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);

	// Create a new Bitmap for the mean removed image
	Bitmap^ meanRemovedBitmap = gcnew Bitmap(originalBitmap->Width, originalBitmap->Height);

	// Define the 3x3 mean removal kernel
	array<array<float>^>^ kernel = gcnew array<array<float>^>(3);
	kernel[0] = gcnew array<float>(3) { -1, -1, -1 };
	kernel[1] = gcnew array<float>(3) { -1, 9, -1 };
	kernel[2] = gcnew array<float>(3) { -1, -1, -1 };

	// Iterate through each pixel of the image, excluding the border
	for (int y = 1; y < originalBitmap->Height - 1; y++) {
		for (int x = 1; x < originalBitmap->Width - 1; x++) {
			float rSum = 0, gSum = 0, bSum = 0;

			// Apply the mean removal convolution filter
			for (int offsetY = -1; offsetY <= 1; offsetY++) {
				for (int offsetX = -1; offsetX <= 1; offsetX++) {
					Color originalColor = originalBitmap->GetPixel(x + offsetX, y + offsetY);
					rSum += originalColor.R * kernel[offsetY + 1][offsetX + 1];
					gSum += originalColor.G * kernel[offsetY + 1][offsetX + 1];
					bSum += originalColor.B * kernel[offsetY + 1][offsetX + 1];
				}
			}

			// Limit from min of 0 and max of 255
			int r = Math::Min(255, Math::Max(0, (int)rSum));
			int g = Math::Min(255, Math::Max(0, (int)gSum));
			int b = Math::Min(255, Math::Max(0, (int)bSum));

			Color newColor = Color::FromArgb(r, g, b);
			meanRemovedBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = meanRemovedBitmap;
}

private: System::Void button28_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Convert the PictureBox's Image to Bitmap
	Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);
	Bitmap^ embossedBitmap = gcnew Bitmap(originalBitmap->Width, originalBitmap->Height);

	// Define the 3x3 Laplacian embossing kernel
	array<array<float>^>^ kernel = gcnew array<array<float>^>(3);
	kernel[0] = gcnew array<float>(3) { -1, 0, -1 };
	kernel[1] = gcnew array<float>(3) { 0, 4, 0 };
	kernel[2] = gcnew array<float>(3) { -1, 0, -1 };

	// Determine the bias
	int bias = 0;
	if (kernel[0][0] == -1 && kernel[0][1] == 0 && kernel[0][2] == -1 &&
		kernel[1][0] == 0 && kernel[1][1] == 4 && kernel[1][2] == 0 &&
		kernel[2][0] == -1 && kernel[2][1] == 0 && kernel[2][2] == -1) {
		bias = 127;
	}

	// Iterate through each pixel of the image, excluding the border
	for (int y = 1; y < originalBitmap->Height - 1; y++) {
		for (int x = 1; x < originalBitmap->Width - 1; x++) {
			float rSum = 0, gSum = 0, bSum = 0;

			for (int offsetY = -1; offsetY <= 1; offsetY++) {
				for (int offsetX = -1; offsetX <= 1; offsetX++) {
					Color originalColor = originalBitmap->GetPixel(x + offsetX, y + offsetY);
					float k = kernel[offsetY + 1][offsetX + 1];
					rSum += originalColor.R * k;
					gSum += originalColor.G * k;
					bSum += originalColor.B * k;
				}
			}

			// Apply the bias and clamp values to the [0, 255] range
			int r = Math::Min(255, Math::Max(0, (int)(rSum + bias)));
			int g = Math::Min(255, Math::Max(0, (int)(gSum + bias)));
			int b = Math::Min(255, Math::Max(0, (int)(bSum + bias)));

			Color newColor = Color::FromArgb(r, g, b);
			embossedBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = embossedBitmap;
}

private: System::Void button25_Click_1(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	// Convert the PictureBox's Image to Bitmap
	System::Drawing::Bitmap^ originalBitmap = gcnew System::Drawing::Bitmap(pictureBox1->Image);

	// Create a new Bitmap for the smoothed image
	System::Drawing::Bitmap^ smoothedBitmap = gcnew System::Drawing::Bitmap(originalBitmap->Width, originalBitmap->Height);

	// Define the 7x7 Gaussian blur kernel
	array<array<float>^>^ kernel = gcnew array<array<float>^>(7);
	for (int i = 0; i < 7; i++) {
		kernel[i] = gcnew array<float>(7);
	}

	// Assign values to the kernel
	kernel[0][0] = 1; kernel[0][1] = 1; kernel[0][2] = 2; kernel[0][3] = 2; kernel[0][4] = 2; kernel[0][5] = 1; kernel[0][6] = 1;
	kernel[1][0] = 1; kernel[1][1] = 2; kernel[1][2] = 2; kernel[1][3] = 4; kernel[1][4] = 2; kernel[1][5] = 2; kernel[1][6] = 1;
	kernel[2][0] = 2; kernel[2][1] = 2; kernel[2][2] = 4; kernel[2][3] = 8; kernel[2][4] = 4; kernel[2][5] = 2; kernel[2][6] = 2;
	kernel[3][0] = 2; kernel[3][1] = 4; kernel[3][2] = 8; kernel[3][3] = 16; kernel[3][4] = 8; kernel[3][5] = 4; kernel[3][6] = 2;
	kernel[4][0] = 2; kernel[4][1] = 2; kernel[4][2] = 4; kernel[4][3] = 8; kernel[4][4] = 4; kernel[4][5] = 2; kernel[4][6] = 2;
	kernel[5][0] = 1; kernel[5][1] = 2; kernel[5][2] = 2; kernel[5][3] = 4; kernel[5][4] = 2; kernel[5][5] = 2; kernel[5][6] = 1;
	kernel[6][0] = 1; kernel[6][1] = 1; kernel[6][2] = 2; kernel[6][3] = 2; kernel[6][4] = 2; kernel[6][5] = 1; kernel[6][6] = 1;
	// Normalize the kernel
	float kernelSum = 0;
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 7; j++) {
			kernelSum += kernel[i][j];
		}
	}
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 7; j++) {
			kernel[i][j] /= kernelSum;
		}
	}

	// Iterate through each pixel of the image, excluding the border
	for (int y = 3; y < originalBitmap->Height - 3; y++) {
		for (int x = 3; x < originalBitmap->Width - 3; x++) {
			float rSum = 0, gSum = 0, bSum = 0;

			// Apply the Gaussian blur convolution filter
			for (int offsetY = -3; offsetY <= 3; offsetY++) {
				for (int offsetX = -3; offsetX <= 3; offsetX++) {
					System::Drawing::Color originalColor = originalBitmap->GetPixel(x + offsetX, y + offsetY);
					rSum += originalColor.R * kernel[offsetY + 3][offsetX + 3];
					gSum += originalColor.G * kernel[offsetY + 3][offsetX + 3];
					bSum += originalColor.B * kernel[offsetY + 3][offsetX + 3];
				}
			}

			// Limit from min of 0 and max of 255
			int r = System::Math::Min(255, System::Math::Max(0, static_cast<int>(rSum + 0.5)));
			int g = System::Math::Min(255, System::Math::Max(0, static_cast<int>(gSum + 0.5)));
			int b = System::Math::Min(255, System::Math::Max(0, static_cast<int>(bSum + 0.5)));

			System::Drawing::Color newColor = System::Drawing::Color::FromArgb(r, g, b);
			smoothedBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = smoothedBitmap;
}

private: System::Void button26_Click(System::Object^ sender, System::EventArgs^ e) {
	// Check if an image is loaded in pictureBox1
	if (pictureBox1->Image == nullptr) { // nullptr means no image is loaded
		// Display an error message if no image is found
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return; // Exit the function if no image is loaded
	}
	// Convert the PictureBox's Image to Bitmap
	Bitmap^ originalBitmap = gcnew Bitmap(pictureBox1->Image);

	// Create a new Bitmap for the sharpened image
	Bitmap^ sharpenedBitmap = gcnew Bitmap(originalBitmap->Width, originalBitmap->Height);

	// Define the 3x3 sharpening kernel
	array<array<float>^>^ kernel = gcnew array<array<float>^>(3);
	kernel[0] = gcnew array<float>(3) { 0, -1, 0 };
	kernel[1] = gcnew array<float>(3) { -1, 5, -1 };
	kernel[2] = gcnew array<float>(3) { 0, -1, 0 };

	// Iterate through each pixel of the image, excluding the border
	for (int y = 1; y < originalBitmap->Height - 1; y++) {
		for (int x = 1; x < originalBitmap->Width - 1; x++) {
			float rSum = 0, gSum = 0, bSum = 0;

			// Apply the sharpening convolution filter
			for (int offsetY = -1; offsetY <= 1; offsetY++) {
				for (int offsetX = -1; offsetX <= 1; offsetX++) {
					Color originalColor = originalBitmap->GetPixel(x + offsetX, y + offsetY);
					rSum += originalColor.R * kernel[offsetY + 1][offsetX + 1];
					gSum += originalColor.G * kernel[offsetY + 1][offsetX + 1];
					bSum += originalColor.B * kernel[offsetY + 1][offsetX + 1];
				}
			}

			// Limit from min of 0 and max of 255
			int r = Math::Min(255, Math::Max(0, (int)rSum));
			int g = Math::Min(255, Math::Max(0, (int)gSum));
			int b = Math::Min(255, Math::Max(0, (int)bSum));

			Color newColor = Color::FromArgb(r, g, b);
			sharpenedBitmap->SetPixel(x, y, newColor);
		}
	}
	pictureBox2->Image = sharpenedBitmap;
}
private: System::Void panel10_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}

private: System::Void button30_Click(System::Object^ sender, System::EventArgs^ e) {
	if (pictureBox1->Image == nullptr) {
		MessageBox::Show("PLEASE REQUIRE AN IMAGE TO PROCESS", "INVALID", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	Bitmap^ original = gcnew Bitmap(pictureBox1->Image);
	int width = original->Width;
	int height = original->Height;

	// Read 3x3 kernel from TextBoxes (as doubles)
	array<array<double>^>^ kernel = {
		gcnew array<double>{
			Double::Parse(textBox3->Text),
			Double::Parse(textBox4->Text),
			Double::Parse(textBox5->Text)
		},
		gcnew array<double>{
			Double::Parse(textBox6->Text),
			Double::Parse(textBox7->Text),
			Double::Parse(textBox8->Text)
		},
		gcnew array<double>{
			Double::Parse(textBox9->Text),
			Double::Parse(textBox10->Text),
			Double::Parse(textBox11->Text)
		}
	};

	// Compute divisor (sum of all kernel values)
	double divisor = 0.0;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			divisor += kernel[i][j];
		}
	}

	// Determine bias
	int bias = 0;
	if (divisor == 0.0) {
		divisor = 1.0;  // Prevent division by zero
		bias = 127;     // Apply bias for visibility
	}

	int kernelRadius = 1;
	int numberOfPasses = 1;

	Bitmap^ currentImage = gcnew Bitmap(original);

	for (int pass = 0; pass < numberOfPasses; pass++) {
		Bitmap^ result = gcnew Bitmap(width, height);

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				double sumR = 0, sumG = 0, sumB = 0;

				for (int ky = -kernelRadius; ky <= kernelRadius; ky++) {
					for (int kx = -kernelRadius; kx <= kernelRadius; kx++) {
						int sampleX = x + kx;
						int sampleY = y + ky;

						if (sampleX >= 0 && sampleX < width && sampleY >= 0 && sampleY < height) {
							Color pixel = currentImage->GetPixel(sampleX, sampleY);
							double kVal = kernel[ky + kernelRadius][kx + kernelRadius];

							sumR += pixel.R * kVal;
							sumG += pixel.G * kVal;
							sumB += pixel.B * kVal;
						}
					}
				}

				// Normalize, apply bias, and clamp
				Color newColor = Color::FromArgb(
					Math::Min(255, Math::Max(0, (int)(sumR / divisor + bias + 0.5))),
					Math::Min(255, Math::Max(0, (int)(sumG / divisor + bias + 0.5))),
					Math::Min(255, Math::Max(0, (int)(sumB / divisor + bias + 0.5)))
				);
				result->SetPixel(x, y, newColor);
			}
		}

		currentImage = result;
	}

	pictureBox2->Image = currentImage;
}

private: System::Void button31_Click(System::Object^ sender, System::EventArgs^ e) {
	
	Finale^ obj1 = gcnew Finale(this);
	obj1->ShowDialog();
	//this->Hide();
}


};
}

